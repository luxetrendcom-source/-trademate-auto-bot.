# TradeMate AI – Auto Trading Bot (PAPER TRADING ONLY)

Everything is simulated. No broker, exchange or real-money order code exists in this package.

## What was added (and what was not touched)
| File | Purpose |
|---|---|
| `TradeMate_AI.html` | Your page + the Auto Bot section. Only 5 original lines changed: nav link, data-notice sentence, FAQ answer, and two one-line hooks in the auth module (`paint()` calls `TMBot.sync()`; `TM` also exposes `toast/client/user`). Auth, plans, journal, dashboard, AI analysis are unchanged. |
| `supabase/migrations/20261117000000_auto_bot.sql` | Tables, row-level security, all paper-trading accounting in SQL functions (service-role only). |
| `supabase/functions/bot-control` | The only write path for the browser. Verifies the user's session, validates every field, checks plan limits, throttles. |
| `supabase/functions/bot-worker` | Background engine, run every minute by pg_cron. Works with no browser open. |
| `supabase/functions/_shared/*` | Server port of your analysis engine (parity-tested against your original browser code), sizing, SL/TP logic. |
| `supabase/cron.sql`, `config.toml` | Schedule + function settings (merge into your existing config.toml). |

Market data is fetched by the worker from **your existing `market-data` function**, using the same request/response shape your page uses. No second provider, no key in new code.

## Deploy (about 10 minutes)
1. **Database:** run `supabase/migrations/20261117000000_auto_bot.sql` in the Supabase SQL editor (or `supabase db push`). It assumes your existing `profiles(id, plan)` table.
2. **Functions:** copy `supabase/functions/*` into your project, merge `config.toml`, then
   `supabase functions deploy bot-control` and `supabase functions deploy bot-worker`.
3. **Secrets:** `supabase secrets set BOT_WORKER_SECRET=<long random string> ALLOWED_ORIGINS=https://your-site.com`
   (`SUPABASE_URL` and the service-role key are provided to functions automatically; never put them in the page). Optional: `MARKET_DATA_URL` if your market-data function lives elsewhere.
4. **Schedule:** edit `supabase/cron.sql` (project ref + the same secret) and run it once in the SQL editor.
5. **Page:** publish `TradeMate_AI.html`. Log in, open **Auto Bot**, choose markets/timeframe, press **Start bot**.
6. Realtime (optional): the migration adds the tables to `supabase_realtime`; if unavailable the page polls every 15 s.

## Behaviour
- Entry: completed-candle BUY/SELL from the same six-indicator engine, score ≥ your minimum; stop = ATR × multiplier, target = stop × reward:risk; simulated slippage; size from risk-per-trade.
- Limits (all configurable): risk per trade, max open positions, daily loss, max drawdown, trades/day, per-market cooldown. Hitting daily-loss or drawdown closes everything and halts. **Emergency stop** does the same on demand.
- Stop button = no new entries; open simulated positions are still managed until SL/TP.
- Plans: free = 2 markets, M15/H1/H4; starter = M5/M15/H1; pro = M5–H4; premium = all. Edit `_shared/plans.ts` (single source of truth; server-enforced, worker halts a bot whose plan no longer allows it).

## Security model
- Browser can only SELECT its own rows (RLS). All writes go through service-role-only SQL functions via `bot-control`.
- One account per user; every query is keyed by the verified user id. Duplicate orders are impossible (`UNIQUE(user_id, signal_key)` + one open position per user/market, under row locks).
- `bot-worker` accepts only the shared-secret header. Set `ALLOWED_ORIGINS` or CORS stays open (`*`).

## Known assumptions / limits
- I could not see your `market-data` function's source, only how the page calls it. The worker calls it without an Authorization header, exactly like the page. If you require auth there, set the header in `_shared/market.ts`.
- Worker runs once a minute: the bot is a minute-level system, not tick-level. Fills are candle-based estimates. Twelve Data credits are shared across all users (one request per market/timeframe, not per user).
- Edge Function TypeScript (`bot-control`, `bot-worker`) could not be executed here (no Deno); their logic is in tested shared modules, but do a smoke test after deploy: Start the bot and watch the activity log.

## Tests (local, optional)
`node --experimental-strip-types --test tests/unit.test.mjs tests/parity.test.mjs tests/e2e.test.mjs` (needs local Postgres, see `tests/pgdb.mjs`) and `node tests/ui.test.mjs` (Playwright).
