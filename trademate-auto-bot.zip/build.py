#!/usr/bin/env python3
"""Rebuilds TradeMate_AI.html = original page + frontend/bot.{css,html,js}. Every anchor must match exactly once."""
import sys
src=open('TradeMate_AI.original.html',encoding='utf8').read(); s=src
def rep(a,b):
    global s
    assert s.count(a)==1,(s.count(a),a[:80]); s=s.replace(a,b)
css=open('frontend/bot.css',encoding='utf8').read(); html=open('frontend/bot.html',encoding='utf8').read(); js=open('frontend/bot.js',encoding='utf8').read()
rep('<a class="m" href="#dash">Dashboard</a><a class="m" href="#journal">','<a class="m" href="#dash">Dashboard</a><a class="m" href="#autobot">Auto Bot</a><a class="m" href="#journal">')
rep('This is analysis only: no broker connection and no order execution.</span></div>','This dashboard is analysis only: no broker connection and no order execution. The Auto Bot below trades a simulated paper account only.</span></div>')
rep('<section id="journal"><h2>Trading journal</h2>',html+'<section id="journal"><h2>Trading journal</h2>')
rep('</style></head>',css+'</style></head>')
rep("paintAcct();if(on)paintJournal()}","paintAcct();if(on)paintJournal();if(window.TMBot)TMBot.sync()}")
rep("return{open:openAuth,logout,profile:openProfile,edit,del,plan}})();","return{open:openAuth,logout,profile:openProfile,edit,del,plan,toast,client:()=>sb,user:()=>user}})();")
rep("<details><summary>Does TradeMate place trades for me?</summary><p>Never. It does not execute trades automatically.</p></details>","<details><summary>Does TradeMate place trades for me?</summary><p>Never with real money. TradeMate has no broker connection and cannot place a real order. The optional Auto Bot trades a simulated paper account with virtual money, so you can test a strategy without risk.</p></details>")
rep("</script>\n</body></html>","</script>\n<script>\n"+js+"</script>\n</body></html>")
open('TradeMate_AI.html','w',encoding='utf8').write(s); print('built',len(s))
