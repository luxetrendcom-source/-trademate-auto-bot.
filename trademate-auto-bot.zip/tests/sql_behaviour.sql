\set ON_ERROR_STOP off
\pset format unaligned
\pset tuples_only on
create temp table t(name text, ok boolean, info text);
create or replace function pg_temp.chk(n text, c boolean, i text default '') returns void language sql as $$ insert into t values (n, coalesce(c,false), i) $$;

insert into auth.users(id,email) values ('aaaaaaaa-0000-0000-0000-000000000001','a@x'),('bbbbbbbb-0000-0000-0000-000000000002','b@x');
select bot_ensure_user('aaaaaaaa-0000-0000-0000-000000000001'); select bot_ensure_user('bbbbbbbb-0000-0000-0000-000000000002');

-- config validation
select pg_temp.chk('config ok', (bot_save_config('aaaaaaaa-0000-0000-0000-000000000001','{"symbols":["EURUSD","USDJPY"],"timeframe":"M15","risk_per_trade_pct":1,"max_open_positions":2,"cooldown_minutes":30}'))->>'ok'='true');
select pg_temp.chk('config out of range rejected', (bot_save_config('aaaaaaaa-0000-0000-0000-000000000001','{"risk_per_trade_pct":50}'))->>'ok'='false');
select pg_temp.chk('config bad symbol rejected', (bot_save_config('aaaaaaaa-0000-0000-0000-000000000001','{"symbols":["DOGE"]}'))->>'ok'='false');
select bot_save_config('bbbbbbbb-0000-0000-0000-000000000002','{"symbols":["EURUSD"]}');

-- open before start is refused (and the signal is consumed)
select pg_temp.chk('open refused when stopped', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|1','EURUSD','M15',1,'buy',80,1.1000,1.0980,1.1040,50000))->>'reason'='bot_not_running');
select bot_start('aaaaaaaa-0000-0000-0000-000000000001'); select bot_start('bbbbbbbb-0000-0000-0000-000000000002');

-- open OK
select pg_temp.chk('open ok', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|2','EURUSD','M15',2,'buy',80,1.1000,1.0980,1.1040,50000))->>'ok'='true');
select pg_temp.chk('duplicate signal blocked', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|2','EURUSD','M15',2,'buy',80,1.1000,1.0980,1.1040,50000))->>'reason'='duplicate');
select pg_temp.chk('second position same symbol blocked', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|3','EURUSD','M15',3,'buy',80,1.1000,1.0980,1.1040,50000))->>'reason'='position_exists');
select pg_temp.chk('bad levels blocked', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','USDJPY|M15|3','USDJPY','M15',3,'buy',80,150,151,152,100))->>'reason'='invalid_levels');
select pg_temp.chk('risk too high blocked', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','USDJPY|M15|4','USDJPY','M15',4,'buy',80,150,149,152,100000))->>'reason'='risk_too_high');
select pg_temp.chk('leverage cap blocked', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','USDJPY|M15|5','USDJPY','M15',5,'buy',80,150,149.99,150.05,1000000))->>'reason'='leverage_limit');
select pg_temp.chk('unconfigured symbol blocked', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','GBPUSD|M15|5','GBPUSD','M15',5,'buy',80,1.3,1.29,1.32,100))->>'reason'='not_configured');
select pg_temp.chk('wrong timeframe blocked', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','USDJPY|H1|5','USDJPY','H1',5,'buy',80,150,149,152,100))->>'reason'='not_configured');

-- isolation of closing
select pg_temp.chk('user B cannot close A position', (paper_close_position('bbbbbbbb-0000-0000-0000-000000000002',(select id from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001'),1.1040,'tp'))->>'ok'='false');
-- mark to market + TP close
select paper_mark_to_market('aaaaaaaa-0000-0000-0000-000000000001','{"EURUSD":1.1020}');
select pg_temp.chk('unrealized pnl = 100', (select unrealized_pnl=100 from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001'));
select pg_temp.chk('equity includes open pnl', (select equity=10100 from paper_accounts where user_id='aaaaaaaa-0000-0000-0000-000000000001'));
select pg_temp.chk('close at tp', (paper_close_position('aaaaaaaa-0000-0000-0000-000000000001',(select id from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001' and status='open'),1.1040,'tp'))->>'pnl'='200.0000');
select pg_temp.chk('balance updated, R=2', (select balance=10200 and equity=10200 and peak_equity=10200 from paper_accounts where user_id='aaaaaaaa-0000-0000-0000-000000000001') and (select r_multiple=2 from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001'));
select pg_temp.chk('B account untouched', (select balance=10000 from paper_accounts where user_id='bbbbbbbb-0000-0000-0000-000000000002'));
select pg_temp.chk('cooldown blocks re-entry', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|9','EURUSD','M15',9,'sell',80,1.1,1.102,1.096,50000))->>'reason'='cooldown');
select pg_temp.chk('close twice rejected', (paper_close_position('aaaaaaaa-0000-0000-0000-000000000001',(select id from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001'),1.1,'manual'))->>'ok'='false');

-- USDJPY conversion: qty 10000 USD, buy 150.00 -> 150.50 = 0.5*10000/150.5 = 33.2226
select bot_save_config('aaaaaaaa-0000-0000-0000-000000000001','{"cooldown_minutes":0}');
select paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','USDJPY|M15|20','USDJPY','M15',20,'buy',80,150,149.25,151.5,10000);
select pg_temp.chk('usdjpy pnl converted', (paper_close_position('aaaaaaaa-0000-0000-0000-000000000001',(select id from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001' and status='open'),150.5,'manual'))->>'pnl'='33.2226');
-- short pnl sign
select paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|21','EURUSD','M15',21,'sell',80,1.1,1.102,1.096,50000);
select pg_temp.chk('short loses when price rises', (paper_close_position('aaaaaaaa-0000-0000-0000-000000000001',(select id from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001' and status='open'),1.101,'sl'))->>'pnl'='-50.0000');

-- stop keeps manageability: stopped bot refuses entries
select bot_stop('aaaaaaaa-0000-0000-0000-000000000001');
select pg_temp.chk('stopped refuses entries', (paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|22','EURUSD','M15',22,'buy',80,1.1,1.098,1.104,50000))->>'reason'='bot_not_running');
select bot_start('aaaaaaaa-0000-0000-0000-000000000001');

-- daily-loss halt: huge adverse mark flattens + halts
select paper_open_position('aaaaaaaa-0000-0000-0000-000000000001','EURUSD|M15|30','EURUSD','M15',30,'buy',80,1.1000,1.0980,1.1040,50000);
select paper_mark_to_market('aaaaaaaa-0000-0000-0000-000000000001','{"EURUSD":1.0600}');
select pg_temp.chk('risk limit halts bot', (select status='halted' and halt_reason in ('daily_loss_limit','max_drawdown') from bot_settings where user_id='aaaaaaaa-0000-0000-0000-000000000001'), (select halt_reason from bot_settings where user_id='aaaaaaaa-0000-0000-0000-000000000001'));
select pg_temp.chk('position flattened with risk_limit', (select count(*)=0 from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001' and status='open') and (select exit_reason='risk_limit' from paper_positions where signal_key='EURUSD|M15|30'));
select pg_temp.chk('cannot restart while breached', (bot_start('aaaaaaaa-0000-0000-0000-000000000001'))->>'ok'='false');
select pg_temp.chk('cannot reset while ... (stopped needed) ok after stop', (paper_reset_account('aaaaaaaa-0000-0000-0000-000000000001',20000))->>'ok'='true');
select pg_temp.chk('reset clears history and restores balance', (select balance=20000 and equity=20000 and peak_equity=20000 from paper_accounts where user_id='aaaaaaaa-0000-0000-0000-000000000001') and (select count(*)=0 from paper_positions where user_id='aaaaaaaa-0000-0000-0000-000000000001'));
select pg_temp.chk('reset rejects bad balance', (paper_reset_account('aaaaaaaa-0000-0000-0000-000000000001',5))->>'ok'='false');

-- emergency stop for B
select paper_open_position('bbbbbbbb-0000-0000-0000-000000000002','EURUSD|M15|1','EURUSD','M15',1,'buy',80,1.1000,1.0980,1.1040,50000);
select pg_temp.chk('B has open position', (select count(*)=1 from paper_positions where user_id='bbbbbbbb-0000-0000-0000-000000000002' and status='open'));
select pg_temp.chk('emergency stop closes 1', (paper_emergency_stop('bbbbbbbb-0000-0000-0000-000000000002'))->>'closed'='1');
select pg_temp.chk('emergency stop halts + flags', (select status='halted' and halt_reason='emergency_stop' from bot_settings where user_id='bbbbbbbb-0000-0000-0000-000000000002') and (select exit_reason='emergency' from paper_positions where user_id='bbbbbbbb-0000-0000-0000-000000000002'));
select pg_temp.chk('emergency stop idempotent', (paper_emergency_stop('bbbbbbbb-0000-0000-0000-000000000002'))->>'closed'='0');
select pg_temp.chk('config change blocked while running', (bot_start('bbbbbbbb-0000-0000-0000-000000000002'))->>'ok'='true' and (bot_save_config('bbbbbbbb-0000-0000-0000-000000000002','{"timeframe":"H1"}'))->>'ok'='false');

-- lease
select pg_temp.chk('lease acquired', bot_acquire_lease('w',30,'h1'));
select pg_temp.chk('lease exclusive', not bot_acquire_lease('w',30,'h2'));
select bot_release_lease('w','h1');
select pg_temp.chk('lease reacquired after release', bot_acquire_lease('w',30,'h2'));
-- throttle
select pg_temp.chk('throttle first ok', bot_throttle('bbbbbbbb-0000-0000-0000-000000000002',1000));
select pg_temp.chk('throttle second blocked', not bot_throttle('bbbbbbbb-0000-0000-0000-000000000002',1000));
select pg_temp.chk('prune runs', (select true from (select bot_prune()) x));

-- RLS and privilege checks as a browser user
create temp table priv(name text, ok boolean);
grant all on t, priv to public;
set role authenticated; set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
select pg_temp.chk('RLS: B sees only own positions', (select count(*)>=1 and bool_and(user_id='bbbbbbbb-0000-0000-0000-000000000002') from paper_positions));
select pg_temp.chk('RLS: B sees only own activity', (select count(*)>=1 and bool_and(user_id='bbbbbbbb-0000-0000-0000-000000000002') from bot_activity));
select pg_temp.chk('RLS: B sees own settings only', (select count(*)=1 from bot_settings));
select pg_temp.chk('server-only table hidden', (select count(*) from (select 1) z)=1);
reset role;
set role authenticated; set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
do $$ begin begin update paper_accounts set balance=1e9; insert into priv values('direct balance write blocked', false); exception when insufficient_privilege then insert into priv values('direct balance write blocked', true); end; end $$;
do $$ begin begin insert into paper_positions(user_id,signal_key,symbol,timeframe,side,qty,entry_price,sl,tp,risk_amount,entry_candle_time) values (auth.uid(),'x','EURUSD','M15','buy',1,1,1,1,1,1); insert into priv values('direct position insert blocked', false); exception when insufficient_privilege then insert into priv values('direct position insert blocked', true); end; end $$;
do $$ begin begin perform paper_emergency_stop(auth.uid()); insert into priv values('browser cannot call RPCs', false); exception when insufficient_privilege then insert into priv values('browser cannot call RPCs', true); end; end $$;
do $$ begin begin perform * from bot_market_state; insert into priv values('server-only table blocked', false); exception when insufficient_privilege then insert into priv values('server-only table blocked', true); end; end $$;
reset role;
insert into t select name, ok, '' from priv;

select (case when ok then 'PASS ' else 'FAIL ' end) || name || case when ok then '' else '  <<< '||info end from t;
select 'TOTAL ' || count(*) || ' FAILED ' || count(*) filter (where not ok) from t;
