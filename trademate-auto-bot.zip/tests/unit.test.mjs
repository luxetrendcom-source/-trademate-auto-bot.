import test from 'node:test';
import assert from 'node:assert/strict';
import { planOrder, scanExit, MAX_LEVERAGE } from '../supabase/functions/_shared/paper.ts';
import { validateConfig, validateBalance, isUuid } from '../supabase/functions/_shared/validate.ts';
import { entitlementError, limitsFor } from '../supabase/functions/_shared/plans.ts';
import { needsFetch, freshness } from '../supabase/functions/_shared/cycle.ts';
import { fetchCandles, MarketError } from '../supabase/functions/_shared/market.ts';

const base = { symbol: 'EURUSD', side: 'buy', price: 1.1, atr: 0.001, equity: 10000, riskPct: 1, slAtrMult: 1.5, rr: 2, slippageBps: 0 };

test('sizing: risk equals risk% of equity, SL/TP on the correct side, RR respected', () => {
  const p = planOrder(base);
  assert.equal(p.sl, 1.0985); assert.equal(p.tp, 1.103);
  assert.ok(p.risk <= 100 && p.risk > 99, 'risk ' + p.risk);
  const s = planOrder({ ...base, side: 'sell' });
  assert.ok(s.sl > s.entry && s.tp < s.entry);
  assert.equal(Math.round(((p.tp - p.entry) / (p.entry - p.sl)) * 100) / 100, 2);
});
test('sizing: slippage is adverse for both sides', () => {
  assert.ok(planOrder({ ...base, slippageBps: 10 }).entry > 1.1);
  assert.ok(planOrder({ ...base, side: 'sell', slippageBps: 10 }).entry < 1.1);
});
test('sizing: USDJPY risk is converted from JPY to USD', () => {
  const p = planOrder({ symbol: 'USDJPY', side: 'buy', price: 150, atr: 0.5, equity: 10000, riskPct: 1, slAtrMult: 1.5, rr: 2, slippageBps: 0 });
  const lossJpy = p.qty * (p.entry - p.sl), lossUsd = lossJpy / p.entry;
  assert.ok(Math.abs(lossUsd - 100) < 1, 'loss at stop ~ $100, got ' + lossUsd);
});
test('sizing: leverage cap shrinks tiny-stop orders; invalid inputs return null', () => {
  const p = planOrder({ ...base, atr: 0.00001 });
  assert.ok(p.notional <= 10000 * MAX_LEVERAGE + 1);
  assert.equal(planOrder({ ...base, atr: 0 }), null);
  assert.equal(planOrder({ ...base, equity: -5 }), null);
  assert.equal(planOrder({ ...base, symbol: 'DOGE' }), null);
});
test('sizing: gold quantity keeps 2 decimals, FX whole units', () => {
  const g = planOrder({ ...base, symbol: 'XAUUSD', price: 2350, atr: 4 });
  assert.equal(g.qty, Math.floor(g.qty * 100) / 100);
  assert.equal(planOrder(base).qty % 1, 0);
});

const C = (time, o, h, l, c) => ({ time, open: o, high: h, low: l, close: c });
const long = { side: 'buy', sl: 1.098, tp: 1.104, entry_candle_time: 1000 };
test('exit: candles before entry ignored; entry candle uses close only', () => {
  assert.equal(scanExit(long, [C(100, 1.1, 1.2, 1.0, 1.1), C(1000, 1.1, 1.11, 1.09, 1.1)]), null);
  // entry candle with a wick through SL that may predate entry -> not an exit
  assert.equal(scanExit(long, [C(1000, 1.1, 1.101, 1.097, 1.0995)]), null);
  // entry candle whose latest close is already through the stop -> exit
  assert.equal(scanExit(long, [C(1000, 1.1, 1.101, 1.097, 1.0975)]).reason, 'sl');
});
test('exit: later candles use high/low; stop wins when both touched', () => {
  assert.deepEqual(scanExit(long, [C(1000, 1.1, 1.1, 1.1, 1.1), C(1900, 1.1, 1.105, 1.1, 1.104)]), { price: 1.104, reason: 'tp', candleTime: 1900 });
  assert.equal(scanExit(long, [C(1000, 1.1, 1.1, 1.1, 1.1), C(1900, 1.1, 1.105, 1.097, 1.1)]).reason, 'sl');
});
test('exit: gap through the stop fills at the (worse) open; sells mirror', () => {
  assert.equal(scanExit(long, [C(1000, 1.1, 1.1, 1.1, 1.1), C(1900, 1.095, 1.096, 1.094, 1.095)]).price, 1.095);
  const short = { side: 'sell', sl: 1.102, tp: 1.096, entry_candle_time: 1000 };
  assert.equal(scanExit(short, [C(1000, 1.1, 1.1, 1.1, 1.1), C(1900, 1.1, 1.1, 1.095, 1.097)]).reason, 'tp');
  assert.equal(scanExit(short, [C(1000, 1.1, 1.1, 1.1, 1.1), C(1900, 1.1, 1.103, 1.099, 1.1)]).price, 1.102);
});

test('config validation accepts valid input and rejects everything else', () => {
  assert.ok(validateConfig({ symbols: ['EURUSD'], timeframe: 'M15', risk_per_trade_pct: 1, close_on_opposite: false }).ok);
  const bad = [null, [], {}, { symbols: [] }, { symbols: ['DOGE'] }, { symbols: ['EURUSD', 'EURUSD'] }, { symbols: 'EURUSD' }, { timeframe: 'M2' },
    { risk_per_trade_pct: 50 }, { risk_per_trade_pct: '1' }, { risk_per_trade_pct: NaN }, { max_open_positions: 1.5 }, { min_score: 59 },
    { close_on_opposite: 'yes' }, { status: 'running' }, { user_id: 'x' }, { balance: 1e9 }, { __proto__x: 1 }];
  for (const b of bad) assert.equal(validateConfig(b).ok, false, JSON.stringify(b));
  assert.equal(validateBalance(5).ok, false); assert.equal(validateBalance(1e9).ok, false); assert.equal(validateBalance('100').ok, false); assert.ok(validateBalance(10000).ok);
  assert.ok(isUuid('aaaaaaaa-0000-0000-0000-000000000001')); assert.equal(isUuid("x'; drop table"), false);
});
test('plans: unknown plan falls back to free; limits enforced', () => {
  assert.equal(limitsFor('weird').maxSymbols, 2);
  assert.match(entitlementError('free', ['EURUSD', 'GBPUSD', 'USDJPY'], 'M15'), /up to 2/);
  assert.match(entitlementError('free', ['EURUSD'], 'M1'), /timeframes/);
  assert.equal(entitlementError('premium', ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD'], 'M1'), null);
});
test('fetch policy: new candle triggers a refresh, otherwise throttled', () => {
  const T = Date.UTC(2026, 10, 17, 10, 0, 20), st = (agoS) => ({ candles: [[1]], fetched_at: new Date(T - agoS * 1000).toISOString() });
  assert.equal(needsFetch(null, 'M15', T), true);
  assert.equal(needsFetch(st(30), 'M15', T), true, 'fetched before the 10:00 candle boundary+15s');
  assert.equal(needsFetch(st(10), 'M15', T), true, 'fetched 10s into the new candle: may predate it at the provider, so retry');
  assert.equal(needsFetch(st(3), 'M15', T), false, 'fetched after boundary+15s');
  assert.equal(needsFetch(st(100), 'M15', T + 60000), true, 'last fetch predates the candle that just closed');
  assert.equal(needsFetch(st(-20), 'M15', T + 60000), false, 'fetched after the boundary, not yet 240s old');
  assert.equal(needsFetch(st(300), 'M15', T + 120000), true, 'periodic refresh');
});
test('freshness mirrors the website (LIVE / DELAYED / STALE / MARKET_CLOSED)', () => {
  const now = Date.UTC(2026, 10, 17, 10, 7), cs = (t) => [{ time: t, open: 1, high: 1, low: 1, close: 1 }];
  assert.equal(freshness(cs(Date.UTC(2026, 10, 17, 10, 0) / 1000), 'M15', now, false).state, 'LIVE');
  assert.equal(freshness(cs(Date.UTC(2026, 10, 17, 8, 0) / 1000), 'M15', now, false).state, 'DELAYED');
  assert.equal(freshness(cs(Date.UTC(2026, 10, 17, 10, 0) / 1000), 'M15', now, true).state, 'STALE');
  assert.equal(freshness(cs(Date.UTC(2026, 10, 17, 10, 0) / 1000), 'M15', now, false, 'stale').tradable, false);
  assert.equal(freshness(cs(1), 'M15', Date.UTC(2026, 10, 21, 12, 0), false).state, 'MARKET_CLOSED');
});
test('market.ts speaks the same protocol as the website and maps errors', async () => {
  const mk = (n) => Array.from({ length: n }, (_, i) => ({ time: i, open: 1, high: 1, low: 1, close: 1 }));
  let url; const ok = (body, status = 200) => async (u) => { url = u; return new Response(JSON.stringify(body), { status }); };
  const r = await fetchCandles('https://x.supabase.co/functions/v1/market-data', 'EURUSD', 'M15', ok({ candles: mk(300), fetched_at: '2026-11-17T10:00:00Z', cache: 'hit' }));
  assert.match(url, /symbol=EUR%2FUSD&interval=15min&outputsize=300/); assert.equal(r.candles.length, 300);
  await assert.rejects(fetchCandles('u', 'EURUSD', 'M15', ok({ error: { kind: 'limit', message: 'cap', retry_after: 90 } }, 429)), (e) => e instanceof MarketError && e.kind === 'limit' && e.retry === 90);
  await assert.rejects(fetchCandles('u', 'EURUSD', 'M15', ok({ candles: mk(50) })), (e) => e.kind === 'unavailable');
  await assert.rejects(fetchCandles('u', 'EURUSD', 'M15', async () => { throw new Error('boom'); }), (e) => e.kind === 'network');
  await assert.rejects(fetchCandles('u', 'DOGE', 'M15', ok({})), (e) => e.kind === 'error');
});
