// Db implementation backed by the psql CLI against a local Postgres, so the REAL worker cycle and the
// REAL SQL functions run together in tests. (Production uses supabase-js; same interface.)
import { execFileSync } from 'node:child_process';

const ENV = { ...process.env, PGHOST: '/tmp/pgtest', PGPORT: '55432', PGUSER: 'pgtest' };
export const sql = (q, db = 'tm') => execFileSync('psql', ['-d', db, '-qAt', '-v', 'ON_ERROR_STOP=1', '-c', q], { env: ENV, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }).trim();
const J = (v) => `$j$${JSON.stringify(v)}$j$::jsonb`;
const lit = (v) => v === null || v === undefined ? 'null' : typeof v === 'number' ? String(v) : typeof v === 'boolean' ? String(v) : typeof v === 'object' ? J(v) : `'${String(v).replace(/'/g, "''")}'`;
const rows = (q) => { const o = sql(`select coalesce(jsonb_agg(to_jsonb(x)), '[]'::jsonb) from (${q}) x`); return JSON.parse(o); };
const list = (ids) => ids.map(lit).join(',') || "''";

export function pgDb() {
  return {
    async rpc(fn, args) {
      const a = Object.entries(args).map(([k, v]) => `${k} => ${lit(v)}`).join(', ');
      const o = sql(`select to_jsonb(public.${fn}(${a}))`);
      return o ? JSON.parse(o) : null;
    },
    async listBots() { return rows(`select * from bot_settings b where status='running' or exists (select 1 from paper_positions p where p.user_id=b.user_id and p.status='open')`); },
    async openPositions(ids) { return rows(`select id,user_id,symbol,side,sl,tp,entry_candle_time from paper_positions where status='open' and user_id::text in (${list(ids)})`); },
    async accounts(ids) { return rows(`select user_id,balance,equity from paper_accounts where user_id::text in (${list(ids)})`); },
    async plans(ids) { const m = {}; for (const r of rows(`select id,plan from profiles where id::text in (${list(ids)})`)) m[r.id] = r.plan; return m; },
    async getMarketState(key) { const r = rows(`select * from bot_market_state where key=${lit(key)}`); return r[0] || null; },
    async saveMarketState(key, patch) {
      const cols = Object.keys(patch), vals = cols.map((c) => lit(patch[c]) + (['candles', 'provider_meta'].includes(c) ? '' : ['fetched_at', 'blocked_until'].includes(c) ? '::timestamptz' : ''));
      sql(`insert into bot_market_state(key, ${cols.join(',')}) values (${lit(key)}, ${vals.join(',')}) on conflict (key) do update set ${cols.map((c) => `${c}=excluded.${c}`).join(',')}`);
    },
    async saveAnalysis(uid, analysis, runAt) { sql(`update bot_settings set last_analysis=${J(analysis)}, last_run_at=${lit(runAt)}::timestamptz where user_id=${lit(uid)}`); },
    async log(uid, level, kind, symbol, message, data) { sql(`insert into bot_activity(user_id,level,kind,symbol,message,data) values (${lit(uid)},${lit(level)},${lit(kind)},${lit(symbol)},${lit(message)},${lit(data ?? null)})`); },
  };
}
