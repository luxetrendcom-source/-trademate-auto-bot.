// PARITY: the server-side engine port must give identical results to the website's original engine.
import test from 'node:test';
import assert from 'node:assert/strict';
import { makeCandles, loadOriginalEngine } from './lib.mjs';
import { analyze } from '../supabase/functions/_shared/engine.ts';

const HTML = new URL('../TradeMate_AI.original.html', import.meta.url).pathname;
const TFS = ['M1', 'M5', 'M15', 'H1', 'H4'], SEC = { M1: 60, M5: 300, M15: 900, H1: 3600, H4: 14400 };

test('server engine == original browser engine on 600 synthetic series', () => {
  const stat = { BUY: 0, SELL: 0, WAIT: 0 };
  let compared = 0;
  for (let seed = 1; seed <= 600; seed++) {
    const tf = TFS[seed % 5], NOW = Date.UTC(2026, 10, 17, 10, 7, 30) + (seed % 7) * 61000;
    const forming = seed % 2 === 0; // alternate: last candle still forming vs already complete
    const endTime = forming ? Math.floor(NOW / 1000 / SEC[tf]) * SEC[tf] : Math.floor(NOW / 1000 / SEC[tf]) * SEC[tf] - SEC[tf];
    const up = (seed % 3) !== 0;
    const mk = (t, s) => makeCandles({ endTimeSec: endTime, tfSec: SEC[t], seed: seed * 10 + s, drift: (up ? 1 : -1) * (0.00002 + (seed % 5) * 0.00002), vol: 0.0001 + (seed % 4) * 0.0001, wave: 0.0005 + (seed % 6) * 0.0003, period: 8 + seed % 13, n: 230 + (seed % 120) });
    const orig = loadOriginalEngine(HTML, NOW);
    const loaded = {};
    // main timeframe + a random subset of other timeframes (to exercise the multi-timeframe score)
    const others = TFS.filter((t) => t !== tf && (seed >> TFS.indexOf(t)) % 2 === 0);
    for (const t of [tf, ...others]) {
      const c = mk(t, TFS.indexOf(t));
      loaded[t] = c;
      const e = orig.ent('EURUSD', t); e.all = c; e.ts = 1;
    }
    const a = orig.analyze('EURUSD', tf), b = analyze(tf, loaded, NOW);
    if (!a || !b) { assert.equal(!!a, !!b, `null mismatch seed ${seed}`); continue; }
    compared++; stat[a.status]++;
    assert.equal(b.status, a.status, `status seed ${seed}`);
    assert.equal(b.score, a.sc, `score seed ${seed}`);
    assert.equal(b.dir, a.d, `dir seed ${seed}`);
    assert.equal(JSON.stringify(b.cond), JSON.stringify(a.cond), `cond seed ${seed}`);
    assert.equal(JSON.stringify(b.mt), JSON.stringify(a.mt), `mt seed ${seed}`);
    assert.equal(b.signalTime, a.ts, `signal time seed ${seed}`);
    assert.equal(b.lastPrice, a.all[a.all.length - 1].close);
    for (const k of ['px', 'rsi', 'macd', 'sig', 'adx', 'atr', 'trend']) assert.equal(b.core[k], a[k], `${k} seed ${seed}`);
    assert.equal(JSON.stringify(b.core.E), JSON.stringify(a.E), `E seed ${seed}`);
    assert.equal(b.core.st.s, a.st.s); assert.equal(JSON.stringify(b.core.st.sr), JSON.stringify(a.st.sr));
  }
  console.log('   compared', compared, 'series; status mix', JSON.stringify(stat));
  assert.ok(compared > 500, 'enough comparisons');
  assert.ok(stat.BUY > 20 && stat.SELL > 20 && stat.WAIT > 20, 'test data must exercise BUY, SELL and WAIT: ' + JSON.stringify(stat));
});
