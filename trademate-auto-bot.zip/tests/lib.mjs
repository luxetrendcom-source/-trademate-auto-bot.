// Shared test helpers: seeded candle generator + loader for the ORIGINAL browser engine (extracted verbatim from the HTML).
import fs from 'node:fs';
import vm from 'node:vm';

export function rng(seed) { let s = seed >>> 0; return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const gauss = (r) => { let u = 0, v = 0; while (!u) u = r(); while (!v) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };

/** Noisy trending series with real swing highs/lows. drift>0 up, <0 down. Last candle starts at endTimeSec. */
export function makeCandles({ n = 320, endTimeSec, tfSec = 900, start = 1.1, drift = 0.00004, vol = 0.00025, wave = 0.0012, period = 14, seed = 1, decimals = 5 }) {
  const r = rng(seed), out = []; let p = start;
  for (let i = 0; i < n; i++) {
    const open = p, target = start + drift * i + wave * Math.sin(i / period * Math.PI * 2);
    const close = open + (target - open) * 0.5 + gauss(r) * vol;
    const hi = Math.max(open, close) + Math.abs(gauss(r)) * vol * 0.6, lo = Math.min(open, close) - Math.abs(gauss(r)) * vol * 0.6;
    out.push({ time: endTimeSec - (n - 1 - i) * tfSec, open: +open.toFixed(decimals), high: +hi.toFixed(decimals), low: +lo.toFixed(decimals), close: +close.toFixed(decimals) });
    p = close;
  }
  return out;
}

export function loadOriginalEngine(htmlPath, NOW) {
  const L = fs.readFileSync(htmlPath, 'utf8').split('\n');
  const pick = (a, b) => L.slice(a - 1, b).join('\n');
  const code = [pick(143, 158), pick(275, 279), pick(312, 313), pick(315, 322)].join('\n') +
    '\nDate.now=()=>__NOW;\n({core,analyze,C,key,ent,TF,S})';
  const ctx = vm.createContext({ __NOW: NOW, Math, Number, Object, Array, Date, Error, JSON, String, isFinite, Infinity });
  const api = vm.runInContext(code, ctx);
  return api;
}
