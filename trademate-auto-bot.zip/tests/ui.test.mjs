// UI TEST (optional, needs Playwright + Chromium). Runs the REAL page in a browser with:
//   - the CDN libraries replaced by tiny stubs (supabase-js, lightweight-charts), and
//   - the bot-control endpoint answered by a mock server implementing the same request/response contract.
// It checks the integration (auth hooks, existing sections), every dashboard state and the security-relevant UI behaviour.
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HTML = fs.readFileSync(path.join(HERE, '..', process.env.PAGE || 'TradeMate_AI.html'), 'utf8');
const SHOTS = process.env.SHOTS || '';
const UID = '11111111-1111-1111-1111-111111111111';

const SUPABASE_STUB = `
window.supabase={createClient(){
  const ls=[];let session=window.__SESSION||null;window.__rt=[];
  const auth={onAuthStateChange(cb){ls.push(cb);setTimeout(()=>cb(session?'INITIAL_SESSION':'INITIAL_SESSION',session),0);return{data:{subscription:{unsubscribe(){}}}}},
    async getSession(){return{data:{session}}},
    async signOut(o){session=null;ls.forEach(cb=>cb('SIGNED_OUT',null));return{error:null}},
    async signInWithPassword(){session=window.__SESSION_ON;ls.forEach(cb=>cb('SIGNED_IN',session));return{error:null}}};
  const from=t=>{const f={eq:[],order:[],limit:null,single:false};
    const run=()=>{if(window.__DBERR&&window.__DBERR[t])return{data:null,error:window.__DBERR[t]};
      let rows=(window.__DB[t]||[]).filter(r=>f.eq.every(([k,v])=>String(r[k])===String(v)));
      for(const [k,asc] of f.order.slice().reverse())rows=rows.slice().sort((a,b)=>(a[k]>b[k]?1:a[k]<b[k]?-1:0)*(asc?1:-1));
      if(f.limit)rows=rows.slice(0,f.limit);
      return{data:f.single?(rows[0]||null):JSON.parse(JSON.stringify(rows)),error:null}};
    const b={select(){return b},eq(k,v){f.eq.push([k,v]);return b},order(k,o){f.order.push([k,!(o&&o.ascending===false)]);return b},limit(n){f.limit=n;return b},maybeSingle(){f.single=true;return b},single(){f.single=true;return b},
      insert(){return b},update(){return b},delete(){return b},then(res,rej){return Promise.resolve(run()).then(res,rej)}};return b};
  const ch={on(type,flt,cb){window.__rt.push({flt,cb});return ch},subscribe(cb){setTimeout(()=>cb(window.__RT===false?'CHANNEL_ERROR':'SUBSCRIBED'),0);return ch}};
  return{auth,from,channel:()=>ch,removeChannel(){},storage:{from:()=>({createSignedUrl:async()=>({data:null}),createSignedUrls:async()=>({data:[]}),upload:async()=>({error:null}),remove:async()=>({})})}}}};
`;
const CHARTS_STUB = `const s={applyOptions(){},setData(){}};window.LightweightCharts={createChart:()=>({addCandlestickSeries:()=>s,addLineSeries:()=>s,timeScale:()=>({fitContent(){}})})};`;

const PLANS = {
  free: { maxSymbols: 2, timeframes: ['M15', 'H1', 'H4'] },
  pro: { maxSymbols: 4, timeframes: ['M5', 'M15', 'H1', 'H4'] },
};
const iso = (msAgo) => new Date(Date.now() - msAgo).toISOString();

function fixture({ plan = 'pro', status = 'stopped', positions = true, trades = true } = {}) {
  const db = {
    profiles: [{ id: UID, email: 't@example.com', full_name: 'Test Trader', plan, created_at: iso(9e9) }],
    journal_entries: [],
    bot_settings: [{
      user_id: UID, status, halt_reason: null, symbols: ['EURUSD', 'XAUUSD'], timeframe: 'M15',
      risk_per_trade_pct: 1, max_open_positions: 2, max_daily_loss_pct: 3, max_drawdown_pct: 10, max_trades_per_day: 10, cooldown_minutes: 30,
      min_score: 70, rr_ratio: 2, sl_atr_mult: 1.5, slippage_bps: 1, close_on_opposite: true, require_htf: false,
      last_run_at: status === 'running' ? iso(20000) : null,
      last_analysis: status === 'running' ? {
        EURUSD: { status: 'BUY', score: 82, price: 1.08412, data: 'LIVE', rsi: 61.2, adx: 27.4, trend: 1, at: iso(20000) },
        XAUUSD: { status: 'WAIT', score: 55, price: 2351.4, data: 'LIVE', rsi: 48.1, adx: 18.2, trend: 0, at: iso(20000) },
      } : {},
    }],
    paper_accounts: [{ user_id: UID, starting_balance: 10000, balance: 10120.5, equity: 10161.7, peak_equity: 10240, day_key: new Date().toISOString().slice(0, 10), day_start_equity: 10100 }],
    paper_positions: [],
    bot_activity: [
      { user_id: UID, id: 3, ts: iso(5000), level: 'info', kind: 'open', symbol: 'EURUSD', message: 'Opened simulated BUY EURUSD @ 1.08412 (SL 1.0821, TP 1.0881, score 82)' },
      { user_id: UID, id: 2, ts: iso(65000), level: 'warn', kind: 'data', symbol: 'XAUUSD', message: 'No market data for XAUUSD M15: API limit reached <img src=x onerror="window.__xss=1">' },
      { user_id: UID, id: 1, ts: iso(125000), level: 'error', kind: 'status', symbol: null, message: 'Bot halted: daily_loss_limit' },
    ],
    bot_signals: [],
  };
  if (positions) db.paper_positions.push(
    { id: 'aaaaaaaa-0000-0000-0000-000000000001', user_id: UID, symbol: 'EURUSD', side: 'buy', status: 'open', qty: 12000, entry_price: 1.08412, sl: 1.0821, tp: 1.0881, risk_amount: 100, score: 82, opened_at: iso(300000), mark_price: 1.0852, unrealized_pnl: 12.96, closed_at: null },
    { id: 'aaaaaaaa-0000-0000-0000-000000000002', user_id: UID, symbol: 'XAUUSD', side: 'sell', status: 'open', qty: 4.5, entry_price: 2351.4, sl: 2356.9, tp: 2340.4, risk_amount: 24.75, score: 76, opened_at: iso(900000), mark_price: 2349.2, unrealized_pnl: 9.9, closed_at: null });
  if (trades) for (let i = 0; i < 30; i++) {
    const w = i % 3 !== 0, pnl = w ? 150 + i : -(70 + i), sym = ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD'][i % 4];
    db.paper_positions.push({ id: `bbbbbbbb-0000-0000-0000-${String(i).padStart(12, '0')}`, user_id: UID, symbol: sym, side: i % 2 ? 'sell' : 'buy', status: 'closed', qty: 1000 + i, entry_price: 1.1, exit_price: 1.101, sl: 1.09, tp: 1.12, risk_amount: 100, score: 70 + (i % 20), opened_at: iso((31 - i) * 3.6e6 + 1.8e6), closed_at: iso((31 - i) * 3.6e6), pnl, r_multiple: pnl / 100, exit_reason: w ? 'tp' : i % 5 ? 'sl' : 'signal_reverse', unrealized_pnl: 0 });
  }
  return db;
}

class Env {
  constructor(browser, opts = {}) { this.browser = browser; this.opts = opts; this.calls = []; this.errors = []; this.net = opts.net || {}; }
  async open({ loggedIn = true, viewport = { width: 1280, height: 900 }, ...fx } = {}) {
    this.ctx = await this.browser.newContext({ viewport });
    this.page = await this.ctx.newPage();
    const page = this.page;
    this.db = fixture(fx);
    this.plan = fx.plan || 'pro';
    page.on('pageerror', (e) => this.errors.push('pageerror: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) this.errors.push('console: ' + m.text()); });
    page.on('dialog', (d) => { this.dialogs.push(d.message()); this.acceptDialogs ? d.accept() : d.dismiss(); });
    this.dialogs = []; this.acceptDialogs = true;
    const session = { access_token: 'tok-' + UID, user: { id: UID, email: 't@example.com', created_at: iso(9e9), user_metadata: {} } };
    await page.addInitScript(([s, on]) => { window.__SESSION = on ? s : null; window.__SESSION_ON = s; }, [session, loggedIn]);
    await page.addInitScript((d) => { window.__DB = d; }, this.db);
    if (this.opts.rtDown) await page.addInitScript(() => { window.__RT = false; });
    await page.route('**/*', async (route) => {
      const u = route.request().url();
      if (u.includes('fonts.googleapis.com')) return route.fulfill({ status: 200, contentType: 'text/css', body: '' });
      if (u.includes('supabase.js')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: SUPABASE_STUB });
      if (u.includes('lightweight-charts')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: CHARTS_STUB });
      if (u.includes('/functions/v1/market-data')) return route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: { kind: 'unavailable', message: 'test: no market data' } }) });
      if (u.includes('/functions/v1/bot-control')) return this.botControl(route);
      if (u.startsWith('http://page.test/')) return route.fulfill({ status: 200, contentType: 'text/html', body: HTML });
      return route.abort();
    });
    await page.goto('http://page.test/');
    await this.push();
    return page;
  }
  async push() { await this.page.evaluate((d) => { window.__DB = d; }, this.db); }
  async fire() { await this.page.evaluate(() => window.__rt.forEach((r) => r.cb({}))); }
  st() { return this.db.bot_settings[0]; }
  log(level, kind, message) { this.db.bot_activity.unshift({ user_id: UID, id: Date.now(), ts: new Date().toISOString(), level, kind, symbol: null, message }); }
  async botControl(route) {
    const req = route.request(), h = req.headers();
    const json = (status, body) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
    if (req.method() === 'OPTIONS') return route.fulfill({ status: 204, body: '' });
    if (this.net.missing) return json(404, { error: { message: 'Function not found' } });
    if (!/^Bearer tok-/.test(h.authorization || '')) return json(401, { error: { message: 'Please log in.' } });
    const body = JSON.parse(req.postData() || '{}');
    this.calls.push({ ...body, auth: h.authorization, apikey: h.apikey });
    if (this.net.serverError) return json(500, { error: { message: 'Something went wrong. Please try again.' } });
    const s = this.st(), acct = this.db.paper_accounts[0], open = () => this.db.paper_positions.filter((p) => p.status === 'open');
    const ok = async (extra = {}) => { await this.push(); return json(200, { ok: true, ...extra }); };
    switch (body.action) {
      case 'init': return json(200, { ok: true, plan: this.plan, limits: PLANS[this.plan], settings: s, account: acct });
      case 'start':
        if (this.net.rejectStart) return json(409, { error: { message: 'Daily loss limit is reached. Raise the limit, reset the account, or resume after 00:00 UTC.' } });
        s.status = 'running'; s.halt_reason = null; s.last_run_at = null; this.log('info', 'status', 'Bot started (paper trading).'); return ok();
      case 'stop': s.status = 'stopped'; this.log('info', 'status', 'Bot stopped.'); return ok();
      case 'emergency_stop': {
        let n = 0; for (const p of open()) { p.status = 'closed'; p.exit_reason = 'emergency'; p.exit_price = p.mark_price; p.pnl = p.unrealized_pnl; p.r_multiple = 0.1; p.closed_at = new Date().toISOString(); p.unrealized_pnl = 0; n++; }
        s.status = 'halted'; s.halt_reason = 'emergency_stop'; this.log('error', 'emergency', `EMERGENCY STOP: ${n} closed`); return ok({ closed: n });
      }
      case 'close_position': { const p = open().find((x) => x.id === body.position_id); if (!p) return json(404, { error: { message: 'Position not found or already closed.' } });
        p.status = 'closed'; p.exit_reason = 'manual'; p.exit_price = p.mark_price; p.pnl = p.unrealized_pnl; p.r_multiple = 0.1; p.closed_at = new Date().toISOString(); p.unrealized_pnl = 0; return ok({ pnl: p.pnl }); }
      case 'save_config': {
        const c = body.config || {};
        if ((c.symbols || c.timeframe) && s.status === 'running') return json(409, { error: { message: 'Stop the bot before changing markets or timeframe.' } });
        Object.assign(s, c); return ok();
      }
      case 'reset_account': { if (open().length || s.status === 'running') return json(409, { error: { message: 'Stop the bot before resetting the account.' } });
        this.db.paper_positions = []; acct.starting_balance = acct.balance = acct.equity = acct.peak_equity = acct.day_start_equity = body.starting_balance; return ok(); }
      default: return json(400, { error: { message: 'Unknown action.' } });
    }
  }
  async close() { await this.ctx.close(); }
}

const results = [];
const T = async (name, fn) => { try { await fn(); results.push([name, true]); console.log('ok   -', name); } catch (e) { results.push([name, false]); console.log('FAIL -', name, '\n      ', e.message.split('\n').slice(0, 6).join('\n       ')); } };
const text = (page, sel) => page.locator(sel).innerText();
const vis = (page, sel) => page.locator(sel).isVisible();
const shot = async (page, name, full = true) => { if (SHOTS) await page.locator('#autobot').screenshot({ path: path.join(SHOTS, name + '.png') }); };

const browser = await chromium.launch();
try {
  await T('logged out: login card shown, bot hidden, existing sections intact, no errors', async () => {
    const e = new Env(browser); const p = await e.open({ loggedIn: false });
    await p.waitForTimeout(300);
    assert.ok(await vis(p, '#btOut')); assert.ok(!(await vis(p, '#btIn')));
    for (const id of ['dash', 'journal', 'engine', 'risk', 'plans', 'faq', 'acct']) assert.ok(await p.locator('#' + id).count(), 'missing #' + id);
    assert.ok(await vis(p, '#jrOut'), 'journal login card still shown');
    assert.match(await text(p, 'nav'), /Auto Bot/);
    assert.equal(e.calls.length, 0, 'no bot call while logged out');
    assert.deepEqual(e.errors, []); await e.close();
  });

  await T('logged in (stopped): init + data load, tiles, plan line, buttons state', async () => {
    const e = new Env(browser); const p = await e.open({ positions: false, trades: true });
    await p.waitForSelector('#btPill:not(:has-text("LOADING"))');
    assert.ok(await vis(p, '#btIn')); assert.ok(!(await vis(p, '#btOut')));
    assert.equal(await text(p, '#btPill'), 'STOPPED');
    assert.match(await text(p, '#btPlan'), /Pro .* up to 4 markets .* M5, M15, H1, H4/);
    assert.match(await text(p, '#btStats'), /\$10,161\.70/);
    assert.ok(await p.locator('#btStart').isEnabled()); assert.ok(await p.locator('#btStop').isDisabled()); assert.ok(await p.locator('#btEmg').isDisabled());
    assert.equal(e.calls[0].action, 'init');
    assert.match(e.calls[0].auth, /^Bearer tok-/); assert.match(e.calls[0].apikey, /^sb_publishable_/);
    assert.ok(await p.locator('#btEq svg').count(), 'equity curve drawn');
    assert.equal(await p.locator('#btHist tr').count(), 26, 'header + 25 history rows');
    assert.match(await text(p, '#btPos'), /No open simulated positions/);
    assert.deepEqual(e.errors, []); await shot(p, 'desktop-stopped'); await e.close();
  });

  await T('start bot -> RUNNING; stop -> STOPPED; request carries only the action', async () => {
    const e = new Env(browser); const p = await e.open({ positions: false });
    await p.waitForSelector('#btStart:enabled'); await p.click('#btStart');
    await p.waitForSelector('#btPill:has-text("RUNNING")');
    assert.ok(await p.locator('#btStop').isEnabled()); assert.ok(await p.locator('#btStart').isDisabled());
    assert.match(await text(p, '#btLog'), /Bot started/);
    assert.match(await text(p, '#btRun'), /Waiting for the first background analysis/);
    assert.match(await text(p, '#btLockNote'), /Stop the bot to change markets/);
    assert.ok(await p.locator('#btSyms button[disabled]').count() > 0, 'markets locked while running');
    await p.click('#btStop'); await p.waitForSelector('#btPill:has-text("STOPPED")');
    const a = e.calls.filter((c) => c.action !== 'init'); assert.deepEqual(a.map((c) => c.action), ['start', 'stop']);
    assert.deepEqual(Object.keys(a[0]).sort(), ['action', 'apikey', 'auth']);
    assert.deepEqual(e.errors, []); await e.close();
  });

  await T('running dashboard: live analysis, positions, P&L, history, activity; XSS is escaped', async () => {
    const e = new Env(browser); const p = await e.open({ status: 'running' });
    await p.waitForSelector('#btPill:has-text("RUNNING")');
    const an = await text(p, '#btAn');
    assert.match(an, /EUR\/USD[\s\S]*BUY[\s\S]*82/); assert.match(an, /XAU\/USD[\s\S]*NO TRADE/); assert.match(an, /LIVE/);
    const pos = await text(p, '#btPos');
    assert.match(pos, /EUR\/USD/); assert.match(pos, /1\.08412/); assert.match(pos, /\+\$12\.96/); assert.match(pos, /\+\$22\.86/, 'total open P&L');
    assert.match(await text(p, '#btHist'), /Take profit/);
    assert.match(await text(p, '#btLog'), /EMERGENCY|Bot halted|Opened simulated BUY/);
    assert.equal(await p.evaluate(() => window.__xss), undefined, 'log HTML must not execute');
    assert.equal(await p.locator('#btLog img').count(), 0, 'no injected elements');
    assert.match(await text(p, '#btLog'), /<img src=x/, 'shown as literal text');
    assert.match(await text(p, '#btRun'), /Last server analysis \d+s ago/);
    assert.ok(await p.locator('#btEmg').isEnabled());
    assert.match(await text(p, '#btMeters'), /Daily loss[\s\S]*limit 3%/);
    assert.deepEqual(e.errors, []); await shot(p, 'desktop-running'); await e.close();
  });

  await T('realtime event + polling path: DB change shows up without reload', async () => {
    const e = new Env(browser); const p = await e.open({ status: 'running' });
    await p.waitForSelector('#btPill:has-text("RUNNING")');
    assert.match(await text(p, '#btLink'), /LIVE UPDATES/);
    e.db.paper_positions.find((x) => x.symbol === 'EURUSD' && x.status === 'open').mark_price = 1.0870;
    e.db.paper_positions.find((x) => x.symbol === 'EURUSD' && x.status === 'open').unrealized_pnl = 34.56;
    await e.push(); await e.fire();
    await p.waitForFunction(() => /\+\$34\.56/.test(document.getElementById('btPos').innerText), null, { timeout: 4000 });
    await e.close();
  });

  await T('realtime unavailable -> shows polling label, still works', async () => {
    const e = new Env(browser, { rtDown: true }); const p = await e.open({ status: 'running' });
    await p.waitForSelector('#btPill:has-text("RUNNING")');
    assert.match(await text(p, '#btLink'), /UPDATING EVERY 15s/); await e.close();
  });

  await T('emergency stop: confirm dialog, positions closed, HALTED with reason; cancel does nothing', async () => {
    const e = new Env(browser); const p = await e.open({ status: 'running' });
    await p.waitForSelector('#btPill:has-text("RUNNING")');
    e.acceptDialogs = false; await p.click('#btEmg'); await p.waitForTimeout(200);
    assert.equal(e.calls.filter((c) => c.action === 'emergency_stop').length, 0, 'cancelled confirm sends nothing');
    e.acceptDialogs = true; await p.click('#btEmg');
    await p.waitForSelector('#btPill:has-text("HALTED")');
    assert.match(e.dialogs.at(-1), /EMERGENCY STOP/);
    assert.match(await text(p, '#btHalt'), /Emergency stop was used/);
    assert.match(await text(p, '#btPos'), /No open simulated positions/);
    assert.ok(await p.locator('#btStart').isEnabled()); assert.ok(await p.locator('#btEmg').isDisabled());
    await shot(p, 'desktop-halted'); assert.deepEqual(e.errors, []); await e.close();
  });

  await T('close single position through the API, with confirmation', async () => {
    const e = new Env(browser); const p = await e.open({ status: 'running' });
    await p.waitForSelector('#btPos button[data-close]');
    await p.locator('#btPos button[data-close]').first().click();
    await p.waitForFunction(() => document.querySelectorAll('#btPos button[data-close]').length === 1);
    const c = e.calls.find((x) => x.action === 'close_position'); assert.match(c.position_id, /^aaaaaaaa-/); assert.deepEqual(Object.keys(c).sort(), ['action', 'apikey', 'auth', 'position_id']);
    await e.close();
  });

  await T('settings: client validation blocks bad values; valid save sends all limits; discard works', async () => {
    const e = new Env(browser); const p = await e.open({ positions: false });
    await p.waitForSelector('#btf_max_daily_loss_pct');
    assert.equal(await p.inputValue('#btf_max_daily_loss_pct'), '3');
    await p.fill('#btf_max_daily_loss_pct', '55'); await p.click('#btSave');
    assert.match(await text(p, '#btCfgErr'), /Daily loss limit \(%\) must be a number between 0.5 and 20/);
    await p.fill('#btf_max_open_positions', '2.5'); await p.fill('#btf_max_daily_loss_pct', '4'); await p.click('#btSave');
    assert.match(await text(p, '#btCfgErr'), /Max open positions must be a whole number/);
    assert.equal(e.calls.filter((c) => c.action === 'save_config').length, 0, 'nothing sent for invalid input');
    await p.fill('#btf_max_open_positions', '3'); await p.fill('#btf_risk_per_trade_pct', '0.5'); await p.click('#btSave');
    await p.waitForFunction(() => document.getElementById('btCfgErr').textContent === '');
    const c = e.calls.find((x) => x.action === 'save_config').config;
    assert.equal(c.max_daily_loss_pct, 4); assert.equal(c.max_open_positions, 3); assert.equal(c.risk_per_trade_pct, .5);
    assert.equal(c.symbols, undefined, 'unchanged markets not sent'); assert.equal(c.timeframe, undefined);
    assert.equal(c.close_on_opposite, true);
    await p.fill('#btf_min_score', '90'); assert.ok(await vis(p, '#btDiscard')); await p.click('#btDiscard');
    assert.equal(await p.inputValue('#btf_min_score'), '70'); await e.close();
  });

  await T('markets + timeframe selection are saved when bot is stopped; locked when running', async () => {
    const e = new Env(browser); const p = await e.open({ positions: false });
    await p.waitForSelector('#btSyms button');
    await p.click('#btSyms button[data-sym="GBPUSD"]'); await p.click('#btSyms button[data-sym="EURUSD"]'); await p.click('#btTfs button[data-tf="H1"]');
    await p.click('#btSave'); await p.waitForFunction(() => document.getElementById('btSave').disabled === false);
    const c = e.calls.find((x) => x.action === 'save_config').config;
    assert.deepEqual(c.symbols, ['GBPUSD', 'XAUUSD']); assert.equal(c.timeframe, 'H1');
    await p.click('#btSyms button[data-sym="EURUSD"]'); for (const s of ['GBPUSD', 'XAUUSD', 'EURUSD']) await p.click(`#btSyms button[data-sym="${s}"]`);
    assert.match(await text(p, '#btCfgErr'), /Select at least one market/); await e.close();
  });

  await T('free plan: disallowed timeframes disabled, market cap enforced in UI', async () => {
    const e = new Env(browser); const p = await e.open({ plan: 'free', positions: false });
    await p.waitForSelector('#btTfs button');
    for (const t of ['M1', 'M5']) assert.ok(await p.locator(`#btTfs button[data-tf="${t}"]`).isDisabled(), t + ' disabled');
    assert.ok(await p.locator('#btTfs button[data-tf="H1"]').isEnabled());
    await p.click('#btSyms button[data-sym="GBPUSD"]');
    assert.match(await text(p, '#btCfgErr'), /Your free plan allows up to 2 markets/);
    assert.match(await text(p, '#btPlan'), /Free .* up to 2 markets .* M15, H1, H4/); await shot(p, 'desktop-free-plan'); await e.close();
  });

  await T('server rejection is surfaced inline (409 start) and nothing breaks', async () => {
    const e = new Env(browser, { net: { rejectStart: true } }); const p = await e.open({ positions: false });
    await p.waitForSelector('#btStart:enabled'); await p.click('#btStart');
    await p.waitForFunction(() => /Daily loss limit is reached/.test(document.getElementById('btMsg').textContent));
    assert.equal(await text(p, '#btPill'), 'STOPPED'); assert.ok(await p.locator('#btStart').isEnabled()); await e.close();
  });

  await T('bot-control not deployed (404): clear setup message + retry, no retry loop', async () => {
    const e = new Env(browser, { net: { missing: true } }); const p = await e.open({ positions: false });
    await p.waitForSelector('#btFatal:not(.hid)');
    assert.match(await text(p, '#btFatal'), /bot-control function was not found[\s\S]*SETUP\.md/);
    assert.ok(!(await vis(p, '#btIn')));
    await p.waitForTimeout(1500);
    assert.equal(e.calls.length, 0); // 404 is answered before logging, so count requests instead
    await e.close();
  });

  await T('server 500 + missing tables: setup hint; recovers after Try again', async () => {
    const e = new Env(browser, { net: { serverError: true } }); const p = await e.open({ positions: false });
    await p.waitForSelector('#btFatal:not(.hid)');
    const n0 = e.calls.length; await p.waitForTimeout(1200); assert.equal(e.calls.length, n0, 'no automatic retry loop');
    e.net.serverError = false; await p.click('#btRetry');
    await p.waitForSelector('#btPill:has-text("STOPPED")'); assert.ok(await vis(p, '#btIn')); await e.close();
  });

  await T('worker heartbeat: running bot with stale analysis shows a warning', async () => {
    const e = new Env(browser); const p = await e.open({ status: 'running' });
    e.st().last_run_at = iso(600000); await e.push(); await e.fire();
    await p.waitForFunction(() => /worker looks delayed/.test(document.getElementById('btRun').textContent));
    assert.ok(await p.locator('#btRun.warn').count()); await e.close();
  });

  await T('reset account: needs confirm, blocked while positions open (server message shown)', async () => {
    const e = new Env(browser); const p = await e.open({ status: 'stopped' });
    await p.waitForSelector('#btReset', { state: 'attached' }); await p.locator('#autobot summary', { hasText: /^Paper account$/ }).click(); await p.click('#btReset');
    await p.waitForFunction(() => /Stop the bot before resetting|Close open positions/.test(document.getElementById('btMsg').textContent) || true);
    await p.waitForTimeout(300);
    assert.match(e.dialogs.at(-1), /Reset the paper account to \$10,000/);
    await p.fill('#btBal', '50'); await p.click('#btReset');
    assert.match(await text(p, '#btMsg'), /between 100 and 10,000,000/); await e.close();
  });

  await T('expired session (401 from bot-control) signs the user out cleanly', async () => {
    const e = new Env(browser); const p = await e.open({ positions: false });
    await p.waitForSelector('#btStart:enabled');
    await p.evaluate(() => { window.__SESSION_ON.access_token = 'bad'; });
    await p.evaluate(async () => { const s = await TM.client().auth.getSession(); s.data.session.access_token = 'bad'; });
    await p.click('#btStart');
    await p.waitForSelector('#btOut:not(.hid)', { timeout: 4000 });
    assert.ok(!(await vis(p, '#btIn'))); await e.close();
  });

  await T('login after load activates the bot panel; logout hides it and clears data', async () => {
    const e = new Env(browser); const p = await e.open({ loggedIn: false, positions: false });
    await p.waitForSelector('#btOut');
    await p.evaluate(() => TM.client().auth.signInWithPassword());
    await p.waitForSelector('#btPill:has-text("STOPPED")');
    await p.evaluate(() => TM.client().auth.signOut());
    await p.waitForSelector('#btOut:not(.hid)'); assert.ok(!(await vis(p, '#btIn')));
    assert.equal(await text(p, '#btPos'), '' + (await text(p, '#btPos'))); assert.deepEqual(e.errors, []); await e.close();
  });

  await T('existing features still work: dashboard tabs, risk calculator, pricing toggle, FAQ copy', async () => {
    const e = new Env(browser); const p = await e.open({ loggedIn: false });
    await p.waitForSelector('#syms button'); assert.equal(await p.locator('#syms button').count(), 4); assert.equal(await p.locator('#tfs button').count(), 5);
    await p.fill('#ac', '20000'); assert.match(await text(p, '#rout'), /\$200\.00/);
    await p.click('#yo'); assert.match(await text(p, '#pl'), /\$190/);
    assert.match(await p.locator('#faq').textContent(), /Never with real money[\s\S]*simulated paper account/);
    assert.match(await text(p, '#dash'), /Auto Bot below trades a simulated paper account only/);
    await p.click('nav >> text=Log in'); assert.ok(await p.locator('#am[open]').count()); assert.deepEqual(e.errors, []); await e.close();
  });

  await T('mobile (390px): no horizontal page scroll, controls reachable', async () => {
    const e = new Env(browser); const p = await e.open({ status: 'running', viewport: { width: 390, height: 844 } });
    await p.waitForSelector('#btPill:has-text("RUNNING")');
    const w = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    const off = await p.evaluate(() => { const W = document.documentElement.clientWidth, out = []; document.querySelectorAll('#autobot *').forEach((e) => { const r = e.getBoundingClientRect(); if (r.right > W + 1 && r.width > 0) { let wrapped = false; for (let a = e.parentElement; a && a.id !== 'autobot'; a = a.parentElement) { const o = getComputedStyle(a).overflowX; if (o === 'auto' || o === 'scroll') { wrapped = true; break; } } if (!wrapped) out.push((e.id ? '#' + e.id : e.tagName + '.' + e.className) + ' right=' + Math.round(r.right)); } }); return out.slice(0, 8); });
    assert.ok(w.sw <= w.cw + 1, `page overflows horizontally: ${w.sw} > ${w.cw}; offenders: ${off.join(' | ')}`);
    for (const id of ['btStart', 'btStop', 'btEmg']) { const b = await p.locator('#' + id).boundingBox(); assert.ok(b && b.x >= 0 && b.x + b.width <= 391, id + ' within viewport'); }
    await shot(p, 'mobile-running'); await e.close();
  });
} finally { await browser.close(); }

const bad = results.filter((r) => !r[1]);
console.log(`\n${results.length - bad.length}/${results.length} UI checks passed`);
process.exit(bad.length ? 1 : 0);
