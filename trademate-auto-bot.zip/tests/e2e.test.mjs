// END-TO-END: real worker cycle (cycle.ts) + real SQL functions + simulated market data.
import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import { makeCandles } from './lib.mjs';
import { analyze, closedCandles } from '../supabase/functions/_shared/engine.ts';
import { runCycle } from '../supabase/functions/_shared/cycle.ts';
import { MarketError } from '../supabase/functions/_shared/market.ts';
import { pgDb, sql } from './pgdb.mjs';

const ENV = { ...process.env, PGHOST: '/tmp/pgtest', PGPORT: '55432', PGUSER: 'pgtest' };
const psqlFile = (f) => execFileSync('psql', ['-d', 'tm', '-q', '-v', 'ON_ERROR_STOP=1', '-f', f], { env: ENV, stdio: 'pipe' });
const U = (n) => `eeeeeeee-0000-0000-0000-00000000000${n}`;
const SEC = { M1: 60, M5: 300, M15: 900, H1: 3600, H4: 14400 };
const NOW = Date.UTC(2026, 10, 17, 10, 7, 30);           // Tuesday, market open
const slot = (now, tf) => Math.floor(now / 1000 / SEC[tf]) * SEC[tf];

// find deterministic series that really produce BUY / SELL on the closed candles
function findSeries(dir, sym, start, decimals) {
  for (let seed = 1; seed < 400; seed++) {
    const c = makeCandles({ endTimeSec: slot(NOW, 'M15'), seed, start, decimals, drift: dir * 0.00006 * (start > 10 ? 100 : 1), vol: 0.0002 * (start > 10 ? 100 : 1), wave: 0.0008 * (start > 10 ? 100 : 1), period: 14 });
    const a = analyze('M15', { M15: c }, NOW);
    if (a && a.status === (dir > 0 ? 'BUY' : 'SELL') && a.score >= 70) return { seed, c, a };
  }
  throw new Error('no series found');
}

test.before(() => {
  sql('drop schema public cascade; create schema public; grant usage on schema public to anon, authenticated, service_role; delete from auth.users', 'tm');
  psqlFile(new URL('../supabase/migrations/20261117000000_auto_bot.sql', import.meta.url).pathname);
  sql(`create table profiles(id uuid primary key, plan text)`);
  for (let i = 1; i <= 6; i++) sql(`insert into auth.users(id,email) values ('${U(i)}','u${i}@x')`);
});

test('full cycle: signals, paper entries, isolation, dedupe, exits, plan limits, API limit, weekend, stale data', async () => {
  const db = pgDb(), buy = findSeries(+1, 'EURUSD', 1.1, 5), sell = findSeries(-1, 'GBPUSD', 1.3, 5);
  console.log(`   EURUSD BUY series seed ${buy.seed} score ${buy.a.score}; GBPUSD SELL series seed ${sell.seed} score ${sell.a.score}`);
  const world = { 'EURUSD|M15': buy.c, 'GBPUSD|M15': sell.c };
  const calls = {}; let failLimit = false, clock = NOW;
  const deps = () => ({
    db, now: () => clock,
    fetchCandles: async (s, t) => {
      calls[`${s}|${t}`] = (calls[`${s}|${t}`] || 0) + 1;
      if (failLimit && s === 'EURUSD' && t === 'H1') throw new MarketError('limit', 'Daily credit limit reached', 300);
      const c = world[`${s}|${t}`]; if (!c) throw new MarketError('unavailable', 'no data in test world');
      return { candles: JSON.parse(JSON.stringify(c)), fetchedAt: clock, cache: 'miss' };
    },
  });

  // users: U1 pro EURUSD; U2 pro EURUSD 2% risk; U3 free but forced onto M1 (simulated downgrade); U5 pro GBPUSD
  const setup = (u, plan, cfg) => { sql(`insert into profiles values ('${U(u)}','${plan}')`); sql(`select bot_ensure_user('${U(u)}')`); sql(`select bot_save_config('${U(u)}', $j$${JSON.stringify(cfg)}$j$::jsonb)`); sql(`select bot_start('${U(u)}')`); };
  setup(1, 'pro', { symbols: ['EURUSD'], timeframe: 'M15', min_score: 70 });
  setup(2, 'pro', { symbols: ['EURUSD'], timeframe: 'M15', min_score: 70, risk_per_trade_pct: 2 });
  setup(5, 'pro', { symbols: ['GBPUSD'], timeframe: 'M15', min_score: 70 });
  setup(3, 'free', { symbols: ['EURUSD'], timeframe: 'M15' }); sql(`update bot_settings set timeframe='M1' where user_id='${U(3)}'`);

  // ---------- cycle 1
  let s = await runCycle(deps());
  console.log('   cycle 1', JSON.stringify(s));
  assert.equal(s.opened, 3, 'U1, U2 and U5 each open one paper position');
  assert.equal(calls['EURUSD|M15'], 1, 'one provider request shared by two users');
  assert.equal(calls['EURUSD|M1'], undefined, 'halted user causes no request');
  assert.equal(sql(`select status||':'||halt_reason from bot_settings where user_id='${U(3)}'`), 'halted:plan_limit');
  const pos = (u) => JSON.parse(sql(`select coalesce(jsonb_agg(to_jsonb(p) order by opened_at),'[]') from paper_positions p where user_id='${U(u)}'`));
  const p1 = pos(1)[0], p2 = pos(2)[0], p5 = pos(5)[0];
  assert.equal(p1.side, 'buy'); assert.equal(p5.side, 'sell'); assert.equal(pos(3).length, 0);
  assert.ok(p1.risk_amount > 98 && p1.risk_amount <= 100, 'U1 risk ~1% ' + p1.risk_amount);
  assert.ok(p2.risk_amount > p1.risk_amount && p2.risk_amount <= 200, 'U2 risks more than U1 but never above 2%: ' + p2.risk_amount);
  assert.ok(p2.qty * p2.entry_price <= 10000 * 25 + 1, 'simulated leverage cap (25x) respected');
  assert.ok(p1.sl < p1.entry_price && p1.tp > p1.entry_price && p5.sl > p5.entry_price && p5.tp < p5.entry_price);
  assert.equal(sql(`select last_analysis->'EURUSD'->>'status' from bot_settings where user_id='${U(1)}'`), 'BUY');
  assert.equal(sql(`select count(*) from bot_signals where user_id='${U(1)}'`), '1');
  assert.ok(+sql(`select count(*) from bot_activity where user_id='${U(1)}' and kind='open'`) === 1);

  // ---------- cycle 2: same data a minute later => no new orders, no new provider calls
  clock = NOW + 60000; s = await runCycle(deps());
  assert.equal(s.opened, 0); assert.equal(calls['EURUSD|M15'], 1, 'no refetch inside the throttle window');
  assert.equal(pos(1).length, 1, 'no duplicate order'); assert.equal(sql(`select count(*) from bot_signals where user_id='${U(1)}'`), '1');
  assert.equal(sql(`select count(*) from paper_positions where status='open'`), '3');

  // ---------- cycle 3: next candle trades through U1/U2's target and U5's stop
  const nextT = slot(NOW, 'M15') + 900, e = world['EURUSD|M15'], g = world['GBPUSD|M15'];
  const lastE = e[e.length - 1], lastG = g[g.length - 1];
  e.push({ time: nextT, open: lastE.close, high: p1.tp + 0.0002, low: lastE.close - 0.0001, close: p1.tp - 0.0001 });
  g.push({ time: nextT, open: lastG.close, high: p5.sl + 0.0003, low: lastG.close - 0.0001, close: lastG.close });
  clock = NOW + 9 * 60000;                                   // 10:16:30, new candle is forming
  s = await runCycle(deps());
  console.log('   cycle 3', JSON.stringify(s));
  assert.equal(s.closed, 3);
  const c1 = pos(1)[0], c2 = pos(2)[0], c5 = pos(5)[0];
  assert.deepEqual([c1.status, c1.exit_reason, c1.exit_price], ['closed', 'tp', p1.tp]);
  assert.deepEqual([c5.status, c5.exit_reason], ['closed', 'sl']); assert.ok(c5.pnl < 0 && c1.pnl > 0);
  assert.ok(Math.abs(c2.pnl / c1.pnl - c2.qty / c1.qty) < 0.01, 'U2 pnl scales with its larger size');
  assert.ok(Math.abs(c1.r_multiple - 2) < 0.15, 'target hit ~ +2R, got ' + c1.r_multiple);
  const bal = (u) => +sql(`select balance from paper_accounts where user_id='${U(u)}'`);
  assert.ok(Math.abs(bal(1) - (10000 + c1.pnl)) < 0.01); assert.ok(bal(5) < 10000); assert.equal(bal(3), 10000, 'unrelated account untouched');
  assert.equal(sql(`select equity from paper_accounts where user_id='${U(1)}'`), sql(`select balance from paper_accounts where user_id='${U(1)}'`), 'flat account: equity == balance');

  // ---------- stopped bot still manages its open position, but takes no new entries
  clock = NOW + 12 * 60000;
  sql(`update bot_settings set cooldown_minutes=0 where user_id='${U(1)}'`);
  sql(`select bot_stop('${U(1)}')`);
  s = await runCycle(deps());
  assert.equal(pos(1).length, 1, 'stopped bot opened nothing');

  // ---------- API limit: backs off, never hammers the provider, user sees a warning
  sql(`select bot_save_config('${U(1)}', '{"symbols":["EURUSD"],"timeframe":"H1","require_htf":false}'::jsonb)`);
  sql(`select bot_start('${U(1)}')`);
  failLimit = true; clock = NOW + 20 * 60000;
  await runCycle(deps()); const before = calls['EURUSD|H1'];
  clock += 60000; await runCycle(deps());
  assert.equal(before, 1); assert.equal(calls['EURUSD|H1'], 1, 'no second request while limit window is active');
  assert.ok(+sql(`select count(*) from bot_activity where user_id='${U(1)}' and kind='data' and level='warn'`) >= 1);
  assert.equal(sql(`select last_analysis->'EURUSD'->>'status' from bot_settings where user_id='${U(1)}'`), 'NO_DATA');
  assert.equal(pos(1).length, 1, 'no entries without data');

  // ---------- weekend: no provider calls, no entries
  failLimit = false; sql(`select bot_stop('${U(1)}')`); sql(`select bot_start('${U(2)}')`);
  const sat = Date.UTC(2026, 10, 21, 12, 0, 0); clock = sat;
  const callsBefore = JSON.stringify(calls); await runCycle(deps());
  assert.equal(JSON.stringify(calls), callsBefore, 'market closed => zero provider requests');

  // ---------- delayed (old) data never trades
  sql(`select bot_stop('${U(2)}')`); setup(4, 'pro', { symbols: ['EURUSD'], timeframe: 'M5', min_score: 60 });
  world['EURUSD|M5'] = makeCandles({ endTimeSec: slot(NOW, 'M5') - 7200, tfSec: 300, seed: buy.seed, drift: 0.00006, vol: 0.0002, wave: 0.0008 });
  clock = NOW + 3 * 3600000 - 3 * 3600000 + 30 * 60000; await runCycle(deps());
  assert.equal(pos(4).length, 0, 'stale/delayed data produces no trades');
  assert.match(sql(`select last_analysis->'EURUSD'->>'data' from bot_settings where user_id='${U(4)}'`), /DELAYED/);
});
