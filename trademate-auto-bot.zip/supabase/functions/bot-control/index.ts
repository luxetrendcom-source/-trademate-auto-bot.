// bot-control: the ONLY way the browser changes bot state. Every request is authenticated against the
// user's Supabase session, strictly validated, plan-checked, throttled and then executed by the
// service_role-only SQL functions. Paper trading only: there is no broker code in this project.

import { createClient } from 'npm:@supabase/supabase-js@2.45.4';
import { ACTIONS, isUuid, validateBalance, validateConfig } from '../_shared/validate.ts';
import { entitlementError, limitsFor, PLAN_LIMITS } from '../_shared/plans.ts';

const URL_ = Deno.env.get('SUPABASE_URL')!, KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ORIGINS = (Deno.env.get('ALLOWED_ORIGINS') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
const sb = createClient(URL_, KEY, { auth: { persistSession: false, autoRefreshToken: false } });

const cors = (req: Request) => {
  const o = req.headers.get('origin') ?? '';
  const allow = ORIGINS.length ? (ORIGINS.includes(o) ? o : ORIGINS[0]) : '*';
  return { 'Access-Control-Allow-Origin': allow, 'Vary': 'Origin', 'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
};
const reply = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors(req), 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const fail = (req: Request, status: number, message: string) => reply(req, { error: { message } }, status);
// Any database error becomes an exception (logged server-side, generic message to the browser).
const rpc = async (fn: string, args: Record<string, unknown>) => {
  const { data, error } = await sb.rpc(fn, args);
  if (error) throw new Error(`${fn}: ${error.message}`);
  return data;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(req) });
  if (req.method !== 'POST') return fail(req, 405, 'Method not allowed.');

  // ---- authenticate (JWT is verified by Supabase Auth, not just decoded)
  const token = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '');
  if (!token) return fail(req, 401, 'Please log in.');
  const { data: ud, error: ue } = await sb.auth.getUser(token);
  if (ue || !ud?.user) return fail(req, 401, 'Your session expired. Please log in again.');
  const uid = ud.user.id;

  // ---- parse + validate
  let body: any;
  try {
    const raw = await req.text();
    if (raw.length > 4096) return fail(req, 413, 'Request too large.');
    body = JSON.parse(raw);
  } catch { return fail(req, 400, 'Invalid request.'); }
  const action = body?.action;
  if (typeof action !== 'string' || !(ACTIONS as readonly string[]).includes(action)) return fail(req, 400, 'Unknown action.');

  try {
    await rpc('bot_ensure_user', { p_user: uid });
    const { data: prof } = await sb.from('profiles').select('plan').eq('id', uid).maybeSingle();
    const plan = prof?.plan ?? 'free', limits = limitsFor(plan);
    const getSettings = async () => {
      const { data, error } = await sb.from('bot_settings').select('*').eq('user_id', uid).single();
      if (error) throw new Error('bot_settings: ' + error.message);
      return data;
    };

    if (action === 'init') {
      const [settings, account] = await Promise.all([getSettings(), sb.from('paper_accounts').select('*').eq('user_id', uid).single().then((r) => { if (r.error) throw new Error('paper_accounts: ' + r.error.message); return r.data; })]);
      return reply(req, { ok: true, plan, limits, plan_limits: PLAN_LIMITS, settings, account, server_time: new Date().toISOString() });
    }

    // every state-changing call is throttled per user (emergency stop is never throttled)
    if (action !== 'emergency_stop') {
      const allowed = await rpc('bot_throttle', { p_user: uid, p_ms: 700 });
      if (!allowed) return fail(req, 429, 'Too many requests. Please wait a moment.');
    }

    let r: any;
    switch (action) {
      case 'save_config': {
        const v = validateConfig(body.config);
        if (!v.ok) return fail(req, 400, v.error);
        const cur = await getSettings();
        const syms = (v.value.symbols as string[] | undefined) ?? cur.symbols, tf = (v.value.timeframe as string | undefined) ?? cur.timeframe;
        const ee = entitlementError(plan, syms, tf);
        if (ee) return fail(req, 403, ee);
        r = await rpc('bot_save_config', { p_user: uid, p_cfg: v.value });
        break;
      }
      case 'start': {
        const cur = await getSettings();
        const ee = entitlementError(plan, cur.symbols, cur.timeframe);
        if (ee) return fail(req, 403, ee);
        r = await rpc('bot_start', { p_user: uid });
        break;
      }
      case 'stop': r = await rpc('bot_stop', { p_user: uid }); break;
      case 'emergency_stop': r = await rpc('paper_emergency_stop', { p_user: uid }); break;
      case 'close_position': {
        if (!isUuid(body.position_id)) return fail(req, 400, 'Invalid position.');
        const { data: p } = await sb.from('paper_positions').select('id,mark_price,entry_price').eq('id', body.position_id).eq('user_id', uid).eq('status', 'open').maybeSingle();
        if (!p) return fail(req, 404, 'Position not found or already closed.');
        r = await rpc('paper_close_position', { p_user: uid, p_position_id: p.id, p_exit: Number(p.mark_price ?? p.entry_price), p_reason: 'manual' });
        break;
      }
      case 'reset_account': {
        if (body.confirm !== true) return fail(req, 400, 'Confirmation required.');
        const b = validateBalance(body.starting_balance);
        if (!b.ok) return fail(req, 400, b.error);
        r = await rpc('paper_reset_account', { p_user: uid, p_balance: b.value });
        break;
      }
    }
    if (!r?.ok) return fail(req, 409, r?.error || 'The request could not be completed.');
    return reply(req, r);
  } catch (e) {
    console.error('bot-control', action, e);
    return fail(req, 500, 'Something went wrong. Please try again.');
  }
});
