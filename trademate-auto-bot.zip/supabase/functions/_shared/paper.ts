// Pure paper-trading helpers: position sizing and SL/TP detection. No I/O, fully unit-tested.
// The authoritative accounting (balances, P&L, risk limits, duplicate prevention) lives in Postgres
// (supabase/migrations/*_auto_bot.sql). Nothing here talks to a broker. There is no broker code anywhere.

import type { Candle } from './engine.ts';

export const DECIMALS: Record<string, number> = { EURUSD: 5, GBPUSD: 5, USDJPY: 3, XAUUSD: 2 };
const round = (v: number, d: number) => Number(v.toFixed(d));
/** Quantity precision: whole units for FX, 0.01 for gold. */
const QTY_DEC: Record<string, number> = { EURUSD: 0, GBPUSD: 0, USDJPY: 0, XAUUSD: 2 };
const floorTo = (v: number, d: number) => { const m = 10 ** d; return Math.floor(v * m + 1e-9) / m; };

/** USD value of 1 unit of quote currency (USDJPY is quoted in JPY). Mirrors paper_pnl() in SQL. */
export const quoteToUsd = (symbol: string, price: number) => symbol === 'USDJPY' ? 1 / price : 1;
/** USD notional of one unit of the instrument. */
export const unitNotionalUsd = (symbol: string, price: number) => symbol === 'USDJPY' ? 1 : price;

export interface OrderInput {
  symbol: string; side: 'buy' | 'sell'; price: number; atr: number; equity: number;
  riskPct: number; slAtrMult: number; rr: number; slippageBps: number;
}
export interface OrderPlan { entry: number; sl: number; tp: number; qty: number; risk: number; notional: number }

/** Max simulated leverage the sizer will use. The database enforces a hard cap of 30x as a second check. */
export const MAX_LEVERAGE = 25;

export function planOrder(o: OrderInput): OrderPlan | null {
  const d = DECIMALS[o.symbol];
  if (d === undefined || !(o.price > 0) || !(o.atr > 0) || !(o.equity > 0)) return null;
  const dir = o.side === 'buy' ? 1 : -1;
  const entry = round(o.price * (1 + dir * o.slippageBps / 1e4), d);          // adverse slippage
  const rawDist = o.atr * o.slAtrMult;
  const sl = round(entry - dir * rawDist, d);
  const tp = round(entry + dir * rawDist * o.rr, d);
  const dist = Math.abs(entry - sl);
  if (!(dist > 0) || (dir > 0 ? !(sl < entry && tp > entry) : !(sl > entry && tp < entry))) return null;
  const riskBudget = o.equity * o.riskPct / 100;
  let qty = riskBudget / (dist * quoteToUsd(o.symbol, entry));
  qty = Math.min(qty, o.equity * MAX_LEVERAGE / unitNotionalUsd(o.symbol, entry));
  qty = floorTo(qty, QTY_DEC[o.symbol]);
  if (!(qty > 0)) return null;
  return { entry, sl, tp, qty, risk: round(qty * dist * quoteToUsd(o.symbol, entry), 4), notional: round(qty * unitNotionalUsd(o.symbol, entry), 2) };
}

export interface OpenPos { side: 'buy' | 'sell'; sl: number; tp: number; entry_candle_time: number; opened_at?: string }
export interface ExitHit { price: number; reason: 'sl' | 'tp'; candleTime: number }

/**
 * Walks candles in order and returns the first stop/target hit.
 *  - candles before the entry candle are ignored
 *  - inside the entry candle only the latest close is trusted (its high/low may predate the entry)
 *  - later candles use high/low (the forming candle included, so touches are caught early)
 *  - if one candle touches BOTH levels the stop wins (conservative)
 *  - a gap open beyond the stop fills at the open (worse), never better than the stop
 */
export function scanExit(pos: OpenPos, candles: Candle[]): ExitHit | null {
  const buy = pos.side === 'buy';
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (c.time < pos.entry_candle_time) continue;
    if (c.time === pos.entry_candle_time) {
      if (i !== candles.length - 1) continue; // only the freshest value of the entry candle is meaningful
      if (buy ? c.close <= pos.sl : c.close >= pos.sl) return { price: pos.sl, reason: 'sl', candleTime: c.time };
      if (buy ? c.close >= pos.tp : c.close <= pos.tp) return { price: pos.tp, reason: 'tp', candleTime: c.time };
      continue;
    }
    const slHit = buy ? c.low <= pos.sl : c.high >= pos.sl;
    const tpHit = buy ? c.high >= pos.tp : c.low <= pos.tp;
    if (slHit) {
      const gapped = buy ? c.open <= pos.sl : c.open >= pos.sl;
      return { price: gapped ? c.open : pos.sl, reason: 'sl', candleTime: c.time };
    }
    if (tpHit) return { price: pos.tp, reason: 'tp', candleTime: c.time };
  }
  return null;
}
