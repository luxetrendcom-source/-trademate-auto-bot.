// supabase-js implementation of the worker's Db interface. Uses the SERVICE ROLE key, which exists only
// as an Edge Function secret and is never sent to a browser.
import type { Db, BotRow, PosRow, AcctRow, MarketState } from './cycle.ts';

type Sb = any; // SupabaseClient
const must = (r: { data: any; error: any }) => { if (r.error) throw new Error(r.error.message); return r.data; };
const chunks = <T>(a: T[], n = 100) => Array.from({ length: Math.ceil(a.length / n) }, (_, i) => a.slice(i * n, i * n + n));

export function supabaseDb(sb: Sb): Db {
  return {
    async rpc(fn, args) { return must(await sb.rpc(fn, args)); },
    async listBots(): Promise<BotRow[]> {
      const running: BotRow[] = must(await sb.from('bot_settings').select('*').eq('status', 'running')) || [];
      const open: { user_id: string }[] = must(await sb.from('paper_positions').select('user_id').eq('status', 'open')) || [];
      const extra = [...new Set(open.map((r) => r.user_id))].filter((id) => !running.some((b) => b.user_id === id));
      let more: BotRow[] = [];
      for (const c of chunks(extra)) more = more.concat(must(await sb.from('bot_settings').select('*').in('user_id', c)) || []);
      return [...running, ...more];
    },
    async openPositions(ids): Promise<PosRow[]> {
      let out: PosRow[] = [];
      for (const c of chunks(ids)) out = out.concat(must(await sb.from('paper_positions').select('id,user_id,symbol,side,sl,tp,entry_candle_time').eq('status', 'open').in('user_id', c)) || []);
      return out;
    },
    async accounts(ids): Promise<AcctRow[]> {
      let out: AcctRow[] = [];
      for (const c of chunks(ids)) out = out.concat(must(await sb.from('paper_accounts').select('user_id,balance,equity').in('user_id', c)) || []);
      return out;
    },
    async plans(ids) {
      const m: Record<string, string> = {};
      for (const c of chunks(ids)) for (const r of must(await sb.from('profiles').select('id,plan').in('id', c)) || []) m[r.id] = r.plan;
      return m;
    },
    async getMarketState(key): Promise<MarketState | null> {
      return must(await sb.from('bot_market_state').select('*').eq('key', key).maybeSingle());
    },
    async saveMarketState(key, patch) { must(await sb.from('bot_market_state').upsert({ key, ...patch }, { onConflict: 'key' })); },
    async saveAnalysis(userId, analysis, runAt) {
      must(await sb.from('bot_settings').update({ last_analysis: analysis, last_run_at: runAt }).eq('user_id', userId));
    },
    async log(userId, level, kind, symbol, message, data) {
      must(await sb.from('bot_activity').insert({ user_id: userId, level, kind, symbol, message, data: data ?? null }));
    },
  };
}
