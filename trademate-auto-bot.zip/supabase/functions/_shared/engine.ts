// Server-side port of the TradeMate AI analysis engine.
// This is a line-for-line port of the indicator + scoring code in the website
// (ema, rsi, wil, adxatr, struct, core, analyze). tests/parity.test.mjs runs the
// ORIGINAL browser code and this port on the same candles and requires identical results.
// If you change the engine on the website, change it here too (the parity test will tell you).

export interface Candle { time: number; open: number; high: number; low: number; close: number }

export const TF = ['M1', 'M5', 'M15', 'H1', 'H4'] as const;
export type Tf = typeof TF[number];
export const TF_MS: Record<string, number> = { M1: 6e4, M5: 3e5, M15: 9e5, H1: 36e5, H4: 144e5 };
export const MINC = 210;

export const ema = (a: number[], p: number): number[] => {
  const k = 2 / (p + 1); let e = a[0];
  return a.map((x, i) => i ? e = x * k + e * (1 - k) : e);
};

export function rsi(c: number[], p = 14): number {
  let g = 0, l = 0; const o: number[] = [];
  for (let i = 1; i < c.length; i++) {
    const d = c[i] - c[i - 1];
    if (i <= p) { g += Math.max(d, 0) / p; l += Math.max(-d, 0) / p; }
    else { g = (g * (p - 1) + Math.max(d, 0)) / p; l = (l * (p - 1) + Math.max(-d, 0)) / p; }
    o.push(100 - 100 / (1 + g / (l || 1e-9)));
  }
  return o.pop() as number;
}

function wil(a: number[], p: number): number[] {
  let s = a.slice(0, p).reduce((x, y) => x + y, 0); const o = [s];
  for (let i = p; i < a.length; i++) o.push(s = s - s / p + a[i]);
  return o;
}

function adxatr(k: Candle[], p = 14) {
  const tr: number[] = [], pd: number[] = [], md: number[] = [];
  for (let i = 1; i < k.length; i++) {
    const u = k[i].high - k[i - 1].high, d = k[i - 1].low - k[i].low;
    pd.push(u > d && u > 0 ? u : 0);
    md.push(d > u && d > 0 ? d : 0);
    tr.push(Math.max(k[i].high - k[i].low, Math.abs(k[i].high - k[i - 1].close), Math.abs(k[i].low - k[i - 1].close)));
  }
  const T = wil(tr, p), P = wil(pd, p), M = wil(md, p);
  const dx = T.map((t, i) => { const a = 100 * P[i] / t, b = 100 * M[i] / t; return 100 * Math.abs(a - b) / ((a + b) || 1); });
  let ax = dx.slice(0, p).reduce((x, y) => x + y, 0) / p;
  for (let i = p; i < dx.length; i++) ax = (ax * (p - 1) + dx[i]) / p;
  return { adx: ax, atr: T[T.length - 1] / p };
}

function struct(k: Candle[]) {
  const H: number[] = [], L: number[] = [];
  for (let i = 3; i < k.length - 3; i++) {
    const w = k.slice(i - 3, i + 4);
    if (k[i].high == Math.max(...w.map((x) => x.high))) H.push(k[i].high);
    if (k[i].low == Math.min(...w.map((x) => x.low))) L.push(k[i].low);
  }
  const h = H.slice(-2), l = L.slice(-2);
  if (h.length < 2 || l.length < 2) return { s: 0, sr: [null, null] as (number | null)[] };
  const s = h[1] > h[0] && l[1] > l[0] ? 1 : h[1] < h[0] && l[1] < l[0] ? -1 : 0;
  return { s, sr: [Math.max(...H.slice(-3)), Math.min(...L.slice(-3))] as (number | null)[] };
}

export interface Core {
  px: number; E: number[]; rsi: number; macd: number; sig: number; adx: number; atr: number;
  st: { s: number; sr: (number | null)[] }; trend: number;
}

export function core(k: Candle[]): Core {
  const c = k.map((x) => x.close), e20 = ema(c, 20), e50 = ema(c, 50), e200 = ema(c, 200), e26 = ema(c, 26);
  const m = ema(c, 12).map((x, i) => x - e26[i]), sg = ema(m, 9), i = c.length - 1, aa = adxatr(k), st = struct(k);
  return {
    px: c[i], E: [e20[i], e50[i], e200[i]], rsi: rsi(c), macd: m[i], sig: sg[i], adx: aa.adx, atr: aa.atr, st,
    trend: c[i] > e200[i] && e20[i] > e50[i] ? 1 : c[i] < e200[i] && e20[i] < e50[i] ? -1 : 0,
  };
}

/** Drops the still-forming last candle. Same rule as the website's closedC(). */
export const closedCandles = (all: Candle[], tf: string, nowMs: number): Candle[] => {
  const l = all[all.length - 1];
  return l.time * 1000 + TF_MS[tf] > nowMs ? all.slice(0, -1) : all;
};

export interface Analysis {
  status: 'BUY' | 'SELL' | 'WAIT';
  score: number;            // 0..100 confirmation score (not a win probability)
  dir: number;              // +1 bullish, -1 bearish, 0 neutral (EMA 20/50/200 trend)
  cond: boolean[];          // the six conditions
  mt: Record<string, number | null>;
  core: Core;
  signalTime: number;       // epoch seconds of the last COMPLETED candle
  lastPrice: number;        // close of the newest candle (forming or not) = current price
  lastTime: number;         // epoch seconds of the newest candle
}

/**
 * Port of the website's analyze(). `loaded` holds the raw candles per timeframe that were fetched;
 * timeframes that were not fetched count as "not loaded" exactly like the website.
 */
export function analyze(tf: string, loaded: Record<string, Candle[] | undefined>, nowMs: number): Analysis | null {
  const all = loaded[tf];
  if (!all || !all.length) return null;
  const k = closedCandles(all, tf, nowMs);
  if (k.length < MINC) return null;
  const x = core(k);
  const mt: Record<string, number | null> = {};
  for (const f of TF) {
    if (f === tf) { mt[f] = x.trend; continue; }
    const o = loaded[f];
    if (o && o.length) {
      const ko = closedCandles(o, f, nowMs);
      mt[f] = ko.length >= MINC ? core(ko).trend : null;
    } else mt[f] = null;
  }
  const d = x.trend, [e20, e50, e200] = x.E, B = d > 0, Sl = d < 0;
  const mb = x.macd > x.sig && x.macd > 0, ms = x.macd < x.sig && x.macd < 0;
  const cond = d > 0
    ? [x.px > e200, e20 > e50, x.rsi > 50, mb, x.adx > 20, x.st.s > 0]
    : [x.px < e200, e20 < e50, x.rsi < 50, ms, x.adx > 20, x.st.s < 0];
  const ok = d != 0 && cond.every(Boolean);
  let sc = 0;
  if (d) {
    sc += (cond[0] && cond[1]) ? 20 : cond[0] || cond[1] ? 10 : 0;
    sc += cond[2] ? (((B && x.rsi > 75) || (Sl && x.rsi < 25)) ? 10 : 15) : 0;
    sc += cond[3] ? 15 : (B ? x.macd > x.sig : x.macd < x.sig) ? 8 : 0;
    sc += x.adx > 25 ? 10 : x.adx > 20 ? 6 : 0;
    sc += cond[5] ? 20 : 0;
    sc += Math.round(20 * TF.filter((f) => mt[f] == d).length / TF.length);
  }
  const status = ok && sc >= 60 ? (B ? 'BUY' : 'SELL') : 'WAIT';
  const last = all[all.length - 1];
  return { status, score: sc, dir: d, cond, mt, core: x, signalTime: k[k.length - 1].time, lastPrice: last.close, lastTime: last.time };
}

/** Same weekend rule as the website's marketClosed(). */
export const marketClosed = (ms: number): boolean => {
  const d = new Date(ms), w = d.getUTCDay(), h = d.getUTCHours();
  return w === 6 || (w === 5 && h >= 22) || (w === 0 && h < 22);
};
