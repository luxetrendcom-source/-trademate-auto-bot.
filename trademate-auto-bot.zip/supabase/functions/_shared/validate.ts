// Strict request validation for the bot-control API. Everything coming from the browser is untrusted.
// Ranges here mirror the CHECK constraints in the migration (the database re-checks them anyway).

import { ALL_SYMBOLS, ALL_TFS } from './plans.ts';

type Rule = { kind: 'num' | 'int'; min: number; max: number } | { kind: 'bool' };
export const CONFIG_RULES: Record<string, Rule> = {
  risk_per_trade_pct: { kind: 'num', min: 0.1, max: 5 },
  max_open_positions: { kind: 'int', min: 1, max: 10 },
  max_daily_loss_pct: { kind: 'num', min: 0.5, max: 20 },
  max_drawdown_pct:   { kind: 'num', min: 1, max: 50 },
  max_trades_per_day: { kind: 'int', min: 1, max: 100 },
  cooldown_minutes:   { kind: 'int', min: 0, max: 1440 },
  min_score:          { kind: 'int', min: 60, max: 100 },
  rr_ratio:           { kind: 'num', min: 0.5, max: 10 },
  sl_atr_mult:        { kind: 'num', min: 0.5, max: 5 },
  slippage_bps:       { kind: 'num', min: 0, max: 50 },
  close_on_opposite:  { kind: 'bool' },
  require_htf:        { kind: 'bool' },
};

export type Valid<T> = { ok: true; value: T } | { ok: false; error: string };

export function validateConfig(input: unknown): Valid<Record<string, unknown>> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return { ok: false, error: 'Invalid configuration.' };
  const src = input as Record<string, unknown>, out: Record<string, unknown> = {};
  for (const k of Object.keys(src)) {
    if (k === 'symbols') {
      const s = src.symbols;
      if (!Array.isArray(s) || s.length < 1 || s.length > ALL_SYMBOLS.length) return { ok: false, error: 'Select between 1 and 4 markets.' };
      if (!s.every((x) => typeof x === 'string' && (ALL_SYMBOLS as readonly string[]).includes(x)) || new Set(s).size !== s.length)
        return { ok: false, error: 'Unknown or duplicate market.' };
      out.symbols = s;
    } else if (k === 'timeframe') {
      if (typeof src.timeframe !== 'string' || !(ALL_TFS as readonly string[]).includes(src.timeframe)) return { ok: false, error: 'Unknown timeframe.' };
      out.timeframe = src.timeframe;
    } else if (k in CONFIG_RULES) {
      const r = CONFIG_RULES[k], v = src[k];
      if (r.kind === 'bool') {
        if (typeof v !== 'boolean') return { ok: false, error: `${k} must be true or false.` };
      } else {
        if (typeof v !== 'number' || !Number.isFinite(v) || (r.kind === 'int' && !Number.isInteger(v)) || v < r.min || v > r.max)
          return { ok: false, error: `${k} must be ${r.kind === 'int' ? 'a whole number ' : 'a number '}between ${r.min} and ${r.max}.` };
      }
      out[k] = v;
    } else return { ok: false, error: `Unknown setting: ${k.slice(0, 40)}.` };
  }
  if (!Object.keys(out).length) return { ok: false, error: 'Nothing to save.' };
  return { ok: true, value: out };
}

export const isUuid = (v: unknown): v is string =>
  typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);

export function validateBalance(v: unknown): Valid<number> {
  if (typeof v !== 'number' || !Number.isFinite(v) || v < 100 || v > 10_000_000) return { ok: false, error: 'Starting balance must be between 100 and 10,000,000.' };
  return { ok: true, value: Math.round(v * 100) / 100 };
}

export const ACTIONS = ['init', 'save_config', 'start', 'stop', 'emergency_stop', 'close_position', 'reset_account'] as const;
