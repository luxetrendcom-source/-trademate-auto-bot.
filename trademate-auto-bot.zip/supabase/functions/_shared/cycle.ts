// One background analysis cycle for ALL running bots. Runs on the server (cron -> bot-worker), so it
// works whether or not any browser is open. Pure orchestration: all I/O goes through `Deps`,
// which lets the same code run in the Edge Function (supabase-js) and in the end-to-end tests (psql).
//
// PAPER TRADING ONLY. The only "execution" is calling the paper_* SQL functions.

import { analyze, type Analysis, type Candle, marketClosed, TF, TF_MS } from './engine.ts';
import { entitlementError } from './plans.ts';
import { planOrder, scanExit } from './paper.ts';
import type { Fetched } from './market.ts';

export interface BotRow {
  user_id: string; status: 'stopped' | 'running' | 'halted'; symbols: string[]; timeframe: string;
  risk_per_trade_pct: number; min_score: number; rr_ratio: number; sl_atr_mult: number; slippage_bps: number;
  close_on_opposite: boolean; require_htf: boolean; last_analysis: Record<string, any> | null;
}
export interface PosRow {
  id: string; user_id: string; symbol: string; side: 'buy' | 'sell'; sl: number; tp: number; entry_candle_time: number;
}
export interface AcctRow { user_id: string; balance: number; equity: number }
export interface MarketState {
  candles: number[][] | null; fetched_at: string | null; provider_meta: any; last_error: string | null; blocked_until: string | null;
}
export interface Db {
  rpc(fn: string, args: Record<string, unknown>): Promise<any>;
  listBots(): Promise<BotRow[]>;
  openPositions(userIds: string[]): Promise<PosRow[]>;
  accounts(userIds: string[]): Promise<AcctRow[]>;
  plans(userIds: string[]): Promise<Record<string, string>>;
  getMarketState(key: string): Promise<MarketState | null>;
  saveMarketState(key: string, patch: Partial<MarketState>): Promise<void>;
  saveAnalysis(userId: string, analysis: Record<string, unknown>, runAt: string): Promise<void>;
  log(userId: string, level: 'info' | 'warn' | 'error', kind: string, symbol: string | null, message: string, data?: unknown): Promise<void>;
}
export interface Deps {
  db: Db;
  fetchCandles: (symbol: string, tf: string) => Promise<Fetched>;
  now: () => number;
  budgetMs?: number;
  concurrency?: number;
}
export interface Summary { bots: number; groups: number; fetched: number; opened: number; closed: number; skipped: number; errors: number; ms: number }

/** Seconds between provider refreshes per timeframe (also gated by the "new candle just closed" rule). */
export const FETCH_EVERY: Record<string, number> = { M1: 60, M5: 120, M15: 240, H1: 600, H4: 1200 };

const num = (v: unknown) => Number(v);
const encode = (c: Candle[]) => c.map((x) => [x.time, x.open, x.high, x.low, x.close]);
const decode = (a: number[][]): Candle[] => a.map((r) => ({ time: r[0], open: r[1], high: r[2], low: r[3], close: r[4] }));
const htfOf = (tf: string) => { const h = TF[Math.min(TF.indexOf(tf as any) + 2, TF.length - 1)]; return h === tf ? null : h; };
const iso = (ms: number) => new Date(ms).toISOString();

export function needsFetch(st: MarketState | null, tf: string, now: number): boolean {
  if (!st || !st.candles || !st.fetched_at) return true;
  const fetched = Date.parse(st.fetched_at);
  if (now - fetched >= FETCH_EVERY[tf] * 1000) return true;
  const boundary = Math.floor(now / TF_MS[tf]) * TF_MS[tf];          // a new candle should now exist
  return now >= boundary + 15000 && fetched < boundary + 15000;
}

export function freshness(candles: Candle[], tf: string, now: number, err: boolean, cache?: string) {
  if (marketClosed(now)) return { state: 'MARKET_CLOSED', tradable: false };
  if (err || cache === 'stale') return { state: 'STALE', tradable: false };
  const age = now - candles[candles.length - 1].time * 1000;
  return age <= TF_MS[tf] * 1.5 + 9e4 ? { state: 'LIVE', tradable: true } : { state: 'DELAYED', tradable: false };
}

interface Group { candles: Candle[] | null; err: { kind: string; message: string } | null; cache?: string }

export async function runCycle(deps: Deps): Promise<Summary> {
  const t0 = deps.now(), deadline = t0 + (deps.budgetMs ?? 45000), db = deps.db;
  const sum: Summary = { bots: 0, groups: 0, fetched: 0, opened: 0, closed: 0, skipped: 0, errors: 0, ms: 0 };
  const bots = await db.listBots();
  if (!bots.length) { sum.ms = deps.now() - t0; return sum; }
  const ids = bots.map((b) => b.user_id);
  const [plans, accts, positions] = await Promise.all([db.plans(ids), db.accounts(ids), db.openPositions(ids)]);
  const acctBy = new Map(accts.map((a) => [a.user_id, a])), plan = (u: string) => plans[u];

  // Plan check: a downgraded account can no longer run a bot outside its plan (open positions are still managed).
  for (const b of bots) {
    if (b.status !== 'running') continue;
    const err = entitlementError(plan(b.user_id), b.symbols, b.timeframe);
    if (err) {
      await db.rpc('bot_halt', { p_user: b.user_id, p_reason: 'plan_limit' });
      await db.log(b.user_id, 'error', 'status', null, 'Bot halted: ' + err);
      b.status = 'halted';
    }
  }

  const activeSyms = (b: BotRow) => b.status === 'running' ? b.symbols
    : b.symbols.filter((s) => positions.some((p) => p.user_id === b.user_id && p.symbol === s));
  const need = new Map<string, [string, string]>();
  for (const b of bots) for (const s of activeSyms(b)) {
    need.set(`${s}|${b.timeframe}`, [s, b.timeframe]);
    const h = b.require_htf && b.status === 'running' ? htfOf(b.timeframe) : null;
    if (h) need.set(`${s}|${h}`, [s, h]);
  }

  // ---- fetch phase: one provider request per distinct (symbol, timeframe), shared by every user
  const groups = new Map<string, Group>();
  for (const [key, [sym, tf]] of need) {
    sum.groups++;
    const now = deps.now();
    let st: MarketState | null = null;
    try { st = await db.getMarketState(key); } catch (_e) { st = null; }
    let candles = st && st.candles ? decode(st.candles) : null;
    let err: Group['err'] = null, cache = st?.provider_meta?.cache as string | undefined;
    if (st?.blocked_until && Date.parse(st.blocked_until) > now) {
      err = { kind: 'blocked', message: st.last_error || 'Market data temporarily unavailable.' };
    } else if (!marketClosed(now) && needsFetch(st, tf, now) && now < deadline) {
      try {
        const f = await deps.fetchCandles(sym, tf);
        candles = f.candles; cache = f.cache; sum.fetched++;
        await db.saveMarketState(key, { candles: encode(f.candles), fetched_at: iso(deps.now()), provider_meta: { cache: f.cache, warning: f.warning, credits: f.credits }, last_error: null, blocked_until: null });
      } catch (e: any) {
        err = { kind: e.kind || 'error', message: String(e.message || e).slice(0, 300) };
        const wait = e.kind === 'limit' ? Math.max(60, Number(e.retry) || 60) : 30;
        await db.saveMarketState(key, { last_error: err.message, blocked_until: iso(deps.now() + wait * 1000) }).catch(() => {});
      }
    }
    groups.set(key, { candles, err, cache });
  }

  // ---- per-bot phase (small concurrency pool; every bot is independent and touches only its own user_id)
  const runBot = async (b: BotRow) => {
    sum.bots++;
    const uid = b.user_id, running = b.status === 'running', now = deps.now(), tf = b.timeframe, hi = htfOf(tf);
    const myPos = positions.filter((p) => p.user_id === uid);
    const acct = acctBy.get(uid);
    const out: Record<string, any> = { ...(b.last_analysis || {}) };
    const marks: Record<string, number> = {};
    try {
      for (const sym of activeSyms(b)) {
        const g = groups.get(`${sym}|${tf}`);
        if (!g || !g.candles) {
          const note = g?.err ? g.err.message : marketClosed(now) ? 'Market closed' : 'Waiting for market data';
          const prev = out[sym]?.note;
          out[sym] = { status: 'NO_DATA', data: g?.err ? 'ERROR' : marketClosed(now) ? 'MARKET_CLOSED' : 'WAITING', note, at: iso(now) };
          if (g?.err && prev !== note) await db.log(uid, 'warn', 'data', sym, `No market data for ${sym} ${tf}: ${note}`);
          continue;
        }
        const candles = g.candles, last = candles[candles.length - 1];
        const fr = freshness(candles, tf, now, !!g.err, g.cache);
        const loaded: Record<string, Candle[] | undefined> = { [tf]: candles };
        if (b.require_htf && hi) loaded[hi] = groups.get(`${sym}|${hi}`)?.candles ?? undefined;
        const a: Analysis | null = analyze(tf, loaded, now);
        marks[sym] = last.close;
        let pos = myPos.find((p) => p.symbol === sym);
        const strong = !!a && a.status !== 'WAIT' && a.score >= b.min_score;

        // 1) stop / target
        if (pos) {
          const hit = scanExit({ side: pos.side, sl: num(pos.sl), tp: num(pos.tp), entry_candle_time: num(pos.entry_candle_time) }, candles);
          if (hit) {
            const r = await db.rpc('paper_close_position', { p_user: uid, p_position_id: pos.id, p_exit: hit.price, p_reason: hit.reason });
            if (r?.ok) sum.closed++;
            pos = undefined;
          } else if (running && b.close_on_opposite && strong && fr.tradable && a!.status !== pos.side.toUpperCase()) {
            const r = await db.rpc('paper_close_position', { p_user: uid, p_position_id: pos.id, p_exit: last.close, p_reason: 'signal_reverse' });
            if (r?.ok) sum.closed++;
            pos = undefined;
          }
        }

        // 2) new entry
        const htfOk = !b.require_htf || !hi || (!!a && a.mt[hi] === a.dir && a.dir !== 0);
        if (running && !pos && strong && fr.tradable && htfOk && acct) {
          const p = planOrder({
            symbol: sym, side: a!.status === 'BUY' ? 'buy' : 'sell', price: last.close, atr: a!.core.atr,
            equity: Math.min(num(acct.balance), num(acct.equity)), riskPct: num(b.risk_per_trade_pct),
            slAtrMult: num(b.sl_atr_mult), rr: num(b.rr_ratio), slippageBps: num(b.slippage_bps),
          });
          if (!p) {
            await db.log(uid, 'warn', 'sizing', sym, `${a!.status} signal on ${sym} ignored: could not size a valid simulated order.`);
          } else {
            const side = a!.status === 'BUY' ? 'buy' : 'sell';
            const res = await db.rpc('paper_open_position', {
              p_user: uid, p_signal_key: `${sym}|${tf}|${a!.signalTime}`, p_symbol: sym, p_tf: tf, p_candle_time: last.time,
              p_side: side, p_score: a!.score, p_price: p.entry, p_sl: p.sl, p_tp: p.tp, p_qty: p.qty,
            });
            if (res?.ok) sum.opened++;
            else if (res?.reason !== 'duplicate') {
              sum.skipped++;
              await db.log(uid, 'info', 'signal', sym, `${a!.status} signal on ${sym} ${tf} (score ${a!.score}) not executed: ${res?.reason}`);
            }
          }
        }

        out[sym] = {
          status: a ? a.status : 'NO_DATA', score: a ? a.score : null, price: last.close, candle_time: last.time,
          signal_time: a ? a.signalTime : null, data: fr.state, rsi: a ? +a.core.rsi.toFixed(1) : null, adx: a ? +a.core.adx.toFixed(1) : null,
          trend: a ? a.dir : null, htf: hi && a ? a.mt[hi] : null, note: g.err ? g.err.message : null, at: iso(now),
        };
      }
      if (Object.keys(marks).length) await db.rpc('paper_mark_to_market', { p_user: uid, p_marks: marks });
      await db.saveAnalysis(uid, out, iso(deps.now()));
    } catch (e: any) {
      sum.errors++;
      await db.log(uid, 'error', 'worker', null, 'Analysis cycle failed: ' + String(e?.message || e).slice(0, 300)).catch(() => {});
    }
  };

  const queue = bots.slice(), workers = Array.from({ length: Math.max(1, deps.concurrency ?? 4) }, async () => {
    for (let b = queue.shift(); b; b = queue.shift()) await runBot(b);
  });
  await Promise.all(workers);
  sum.ms = deps.now() - t0;
  return sum;
}
