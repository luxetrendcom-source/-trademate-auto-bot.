// Candle fetching. This REUSES the website's existing "market-data" Edge Function (which holds the
// Twelve Data key), so there is no second provider integration and no key in this code.
// Request and response shapes are exactly what the website's api() function sends and expects.

import type { Candle } from './engine.ts';

export const PROVIDER_SYMBOL: Record<string, string> = { EURUSD: 'EUR/USD', GBPUSD: 'GBP/USD', USDJPY: 'USD/JPY', XAUUSD: 'XAU/USD' };
export const INTERVAL: Record<string, string> = { M1: '1min', M5: '5min', M15: '15min', H1: '1h', H4: '4h' };

export class MarketError extends Error {
  kind: string; retry?: number;
  constructor(kind: string, message: string, retry?: number) { super(message); this.kind = kind; this.retry = retry; }
}
export interface Fetched { candles: Candle[]; fetchedAt: number; cache?: string; warning?: string; credits?: unknown }

export async function fetchCandles(marketDataUrl: string, symbol: string, tf: string, fetchImpl: typeof fetch = fetch): Promise<Fetched> {
  const ps = PROVIDER_SYMBOL[symbol], iv = INTERVAL[tf];
  if (!ps || !iv) throw new MarketError('error', 'Unsupported symbol or timeframe.');
  const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 20000);
  let r: Response, j: any = null;
  try {
    r = await fetchImpl(`${marketDataUrl}?symbol=${encodeURIComponent(ps)}&interval=${iv}&outputsize=300`, { signal: ctrl.signal });
  } catch (_e) {
    throw new MarketError('network', 'Could not reach the market data function.');
  } finally { clearTimeout(to); }
  try { j = await r.json(); } catch (_e) { j = null; }
  if (!r.ok || !j || j.error) {
    const x = j && j.error;
    if (x) throw new MarketError(x.kind || 'error', x.message || 'Market data request failed.', x.retry_after);
    throw new MarketError(r.status === 404 ? 'config' : 'error', r.status === 404 ? 'market-data function not found.' : `Market data request failed (HTTP ${r.status}).`);
  }
  const candles: Candle[] = (j.candles || []).filter((x: any) =>
    [x.time, x.open, x.high, x.low, x.close].every((v: unknown) => typeof v === 'number' && Number.isFinite(v)));
  candles.sort((a, b) => a.time - b.time);
  if (candles.length < 211) throw new MarketError('unavailable', `Only ${candles.length} candles returned for ${ps} ${tf}; at least 211 are needed.`);
  return { candles, fetchedAt: Date.parse(j.fetched_at) || Date.now(), cache: j.cache, warning: j.warning, credits: j.credits || null };
}
