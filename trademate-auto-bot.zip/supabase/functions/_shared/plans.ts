// Entitlements per subscription plan (profiles.plan). Single source of truth for the backend;
// the dashboard receives these limits from the bot-control API and never decides on its own.
// Derived from the pricing cards on the website (instruments / timeframes per plan). Edit freely.

export const ALL_SYMBOLS = ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD'] as const;
export const ALL_TFS = ['M1', 'M5', 'M15', 'H1', 'H4'] as const;

export interface PlanLimits { maxSymbols: number; timeframes: string[] }

export const PLAN_LIMITS: Record<string, PlanLimits> = {
  free:    { maxSymbols: 2, timeframes: ['M15', 'H1', 'H4'] },
  starter: { maxSymbols: 4, timeframes: ['M5', 'M15', 'H1'] },
  pro:     { maxSymbols: 4, timeframes: ['M5', 'M15', 'H1', 'H4'] },
  premium: { maxSymbols: 4, timeframes: ['M1', 'M5', 'M15', 'H1', 'H4'] },
};

export const limitsFor = (plan: string | null | undefined): PlanLimits =>
  PLAN_LIMITS[String(plan || 'free').toLowerCase()] || PLAN_LIMITS.free;

/** null when entitled, otherwise a human-readable reason. */
export function entitlementError(plan: string | null | undefined, symbols: string[], tf: string): string | null {
  const l = limitsFor(plan);
  if (symbols.length > l.maxSymbols) return `Your plan allows up to ${l.maxSymbols} markets for the bot.`;
  if (!l.timeframes.includes(tf)) return `Your plan allows these bot timeframes: ${l.timeframes.join(', ')}.`;
  return null;
}
