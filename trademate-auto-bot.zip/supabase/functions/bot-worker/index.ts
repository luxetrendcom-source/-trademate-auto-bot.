// bot-worker: the background engine. Invoked every minute by pg_cron (see supabase/cron.sql), so the bot
// keeps analysing and managing PAPER positions with no browser open.
// Auth: shared secret header (x-bot-secret). Not callable by browser users.

import { createClient } from 'npm:@supabase/supabase-js@2.45.4';
import { runCycle } from '../_shared/cycle.ts';
import { fetchCandles } from '../_shared/market.ts';
import { supabaseDb } from '../_shared/supabase-db.ts';

const URL_ = Deno.env.get('SUPABASE_URL')!, KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const SECRET = Deno.env.get('BOT_WORKER_SECRET') ?? '';
const MARKET_URL = Deno.env.get('MARKET_DATA_URL') ?? `${URL_}/functions/v1/market-data`;
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { 'Content-Type': 'application/json' } });

function safeEqual(a: string, b: string) {
  const x = new TextEncoder().encode(a), y = new TextEncoder().encode(b);
  let d = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) d |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return d === 0;
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  if (!SECRET || !safeEqual(req.headers.get('x-bot-secret') ?? '', SECRET)) return json({ error: 'Unauthorized' }, 401);

  const sb = createClient(URL_, KEY, { auth: { persistSession: false, autoRefreshToken: false } });
  const holder = crypto.randomUUID();
  const { data: got, error: le } = await sb.rpc('bot_acquire_lease', { p_name: 'worker', p_seconds: 120, p_holder: holder });
  if (le) { console.error('lease', le.message); return json({ error: 'Lease failed' }, 500); }
  if (!got) return json({ skipped: 'another run is still active' });

  try {
    const summary = await runCycle({ db: supabaseDb(sb), fetchCandles: (s, t) => fetchCandles(MARKET_URL, s, t), now: Date.now, budgetMs: 50000 });
    if (new Date().getUTCMinutes() === 0) await sb.rpc('bot_prune');
    return json({ ok: true, ...summary });
  } catch (e) {
    console.error('worker cycle failed', e);
    return json({ error: 'Cycle failed' }, 500);
  } finally {
    await sb.rpc('bot_release_lease', { p_name: 'worker', p_holder: holder });
  }
});
