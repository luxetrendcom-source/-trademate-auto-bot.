-- =====================================================================
-- TradeMate AI : Auto Trading Bot  (PAPER TRADING ONLY)
-- No broker connection exists anywhere in this schema. Every "position",
-- "trade" and "balance" below is a simulation record.
--
-- Security model
--   * Browser users can only SELECT their own rows (RLS).
--   * Every write goes through SECURITY DEFINER functions that only the
--     service_role (Edge Functions) may execute. The browser cannot write
--     balances, positions or settings directly.
--   * One account per user (user_id primary key), all rows carry user_id.
--   * Duplicate orders are impossible: UNIQUE(user_id, signal_key) and a
--     partial UNIQUE index allowing one open position per user + symbol.
--   * All state changes happen under row locks (settings first, then
--     account, always in that order) so overlapping calls serialise.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- tables
create table if not exists public.bot_settings (
  user_id            uuid primary key references auth.users(id) on delete cascade,
  status             text not null default 'stopped' check (status in ('stopped','running','halted')),
  halt_reason        text,
  halted_at          timestamptz,
  started_at         timestamptz,
  symbols            text[] not null default array['EURUSD']
                       check (cardinality(symbols) between 1 and 4
                              and symbols <@ array['EURUSD','GBPUSD','USDJPY','XAUUSD']),
  timeframe          text not null default 'M15' check (timeframe in ('M1','M5','M15','H1','H4')),
  -- simulation risk limits
  risk_per_trade_pct numeric(5,2) not null default 1    check (risk_per_trade_pct between 0.1 and 5),
  max_open_positions int          not null default 2    check (max_open_positions between 1 and 10),
  max_daily_loss_pct numeric(5,2) not null default 3    check (max_daily_loss_pct between 0.5 and 20),
  max_drawdown_pct   numeric(5,2) not null default 10   check (max_drawdown_pct between 1 and 50),
  max_trades_per_day int          not null default 10   check (max_trades_per_day between 1 and 100),
  cooldown_minutes   int          not null default 30   check (cooldown_minutes between 0 and 1440),
  -- strategy
  min_score          int          not null default 70   check (min_score between 60 and 100),
  rr_ratio           numeric(4,2) not null default 2    check (rr_ratio between 0.5 and 10),
  sl_atr_mult        numeric(4,2) not null default 1.5  check (sl_atr_mult between 0.5 and 5),
  slippage_bps       numeric(5,2) not null default 1    check (slippage_bps between 0 and 50),
  close_on_opposite  boolean      not null default true,
  require_htf        boolean      not null default false,
  -- runtime
  last_run_at        timestamptz,
  last_analysis      jsonb not null default '{}'::jsonb,
  last_control_at    timestamptz,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists public.paper_accounts (
  user_id            uuid primary key references auth.users(id) on delete cascade,
  starting_balance   numeric(18,2) not null default 10000 check (starting_balance between 100 and 10000000),
  balance            numeric(18,4) not null default 10000,   -- realised cash
  equity             numeric(18,4) not null default 10000,   -- balance + open P&L
  peak_equity        numeric(18,4) not null default 10000,
  day_key            date not null default ((now() at time zone 'utc')::date),
  day_start_equity   numeric(18,4) not null default 10000,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists public.paper_positions (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references auth.users(id) on delete cascade,
  signal_key         text not null,
  symbol             text not null check (symbol in ('EURUSD','GBPUSD','USDJPY','XAUUSD')),
  timeframe          text not null,
  side               text not null check (side in ('buy','sell')),
  status             text not null default 'open' check (status in ('open','closed')),
  qty                numeric(24,8) not null check (qty > 0),
  entry_price        numeric(18,6) not null check (entry_price > 0),
  sl                 numeric(18,6) not null,
  tp                 numeric(18,6) not null,
  risk_amount        numeric(18,4) not null,
  score              int,
  entry_candle_time  bigint not null,               -- epoch seconds of the candle the entry happened in
  opened_at          timestamptz not null default now(),
  mark_price         numeric(18,6),
  mark_at            timestamptz,
  unrealized_pnl     numeric(18,4) not null default 0,
  exit_price         numeric(18,6),
  exit_reason        text check (exit_reason in ('tp','sl','manual','emergency','risk_limit','signal_reverse')),
  pnl                numeric(18,4),
  r_multiple         numeric(10,3),
  closed_at          timestamptz,
  unique (user_id, signal_key)
);
create unique index if not exists paper_one_open_per_symbol
  on public.paper_positions (user_id, symbol) where status = 'open';
create index if not exists paper_positions_user_status on public.paper_positions (user_id, status, opened_at desc);
create index if not exists paper_positions_user_closed on public.paper_positions (user_id, closed_at desc) where status = 'closed';

create table if not exists public.bot_signals (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  signal_key  text not null,
  symbol      text not null,
  timeframe   text not null,
  candle_time bigint not null,
  side        text not null check (side in ('buy','sell')),
  score       int,
  price       numeric(18,6),
  outcome     text not null default 'pending' check (outcome in ('pending','opened','skipped')),
  detail      text,
  position_id uuid,
  created_at  timestamptz not null default now(),
  unique (user_id, signal_key)
);
create index if not exists bot_signals_user_time on public.bot_signals (user_id, created_at desc);

create table if not exists public.bot_activity (
  id      bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  ts      timestamptz not null default now(),
  level   text not null default 'info' check (level in ('info','warn','error')),
  kind    text not null,
  symbol  text,
  message text not null,
  data    jsonb
);
create index if not exists bot_activity_user_ts on public.bot_activity (user_id, ts desc);

-- Server-only tables (RLS on, no policies, no grants => unreachable from the browser)
create table if not exists public.bot_market_state (
  key           text primary key,                 -- 'EURUSD|M15'
  candles       jsonb,
  fetched_at    timestamptz,
  provider_meta jsonb,
  last_error    text,
  blocked_until timestamptz
);
create table if not exists public.bot_worker_lease (
  name         text primary key,
  holder       text,
  locked_until timestamptz not null default now()
);

-- -------------------------------------------------------------- RLS / grants
alter table public.bot_settings     enable row level security;
alter table public.paper_accounts   enable row level security;
alter table public.paper_positions  enable row level security;
alter table public.bot_signals      enable row level security;
alter table public.bot_activity     enable row level security;
alter table public.bot_market_state enable row level security;
alter table public.bot_worker_lease enable row level security;

do $$ declare t text; begin
  foreach t in array array['bot_settings','paper_accounts','paper_positions','bot_signals','bot_activity'] loop
    execute format('drop policy if exists "own rows read" on public.%I', t);
    execute format('create policy "own rows read" on public.%I for select to authenticated using (user_id = (select auth.uid()))', t);
  end loop;
end $$;

revoke all on public.bot_settings, public.paper_accounts, public.paper_positions,
              public.bot_signals, public.bot_activity, public.bot_market_state,
              public.bot_worker_lease from anon, authenticated;
grant select on public.bot_settings, public.paper_accounts, public.paper_positions,
                public.bot_signals, public.bot_activity to authenticated;

-- ------------------------------------------------------------------ helpers
create or replace function public._bot_log(p_user uuid, p_level text, p_kind text, p_symbol text, p_msg text, p_data jsonb default null)
returns void language sql security definer set search_path = public, pg_temp as $$
  insert into public.bot_activity(user_id, level, kind, symbol, message, data) values (p_user, p_level, p_kind, p_symbol, p_msg, p_data);
$$;

-- Simulated P&L in USD. Quote currency of USDJPY is JPY, so it is converted at the exit price.
create or replace function public.paper_pnl(p_symbol text, p_side text, p_qty numeric, p_entry numeric, p_exit numeric)
returns numeric language sql immutable as $$
  select round((p_exit - p_entry) * p_qty * (case when p_side = 'buy' then 1 else -1 end)
               * (case when p_symbol = 'USDJPY' then 1 / nullif(p_exit, 0) else 1 end), 4)
$$;

create or replace function public._paper_refresh_equity(p_user uuid)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare eq numeric;
begin
  select a.balance + coalesce((select sum(p.unrealized_pnl) from public.paper_positions p where p.user_id = p_user and p.status = 'open'), 0)
    into eq from public.paper_accounts a where a.user_id = p_user;
  update public.paper_accounts set equity = eq, peak_equity = greatest(peak_equity, eq), updated_at = now() where user_id = p_user;
end $$;

create or replace function public._paper_roll_day(p_user uuid)
returns void language sql security definer set search_path = public, pg_temp as $$
  update public.paper_accounts
     set day_key = (now() at time zone 'utc')::date, day_start_equity = equity, updated_at = now()
   where user_id = p_user and day_key <> (now() at time zone 'utc')::date;
$$;

-- Closes one open position. Caller must already hold the settings+account locks.
create or replace function public._paper_close(p_id uuid, p_exit numeric, p_reason text)
returns numeric language plpgsql security definer set search_path = public, pg_temp as $$
declare pos public.paper_positions; v_pnl numeric;
begin
  select * into pos from public.paper_positions where id = p_id and status = 'open' for update;
  if not found then return null; end if;
  v_pnl := public.paper_pnl(pos.symbol, pos.side, pos.qty, pos.entry_price, p_exit);
  update public.paper_positions
     set status = 'closed', exit_price = p_exit, exit_reason = p_reason, pnl = v_pnl,
         r_multiple = case when risk_amount > 0 then round(v_pnl / risk_amount, 3) end,
         closed_at = now(), mark_price = p_exit, mark_at = now(), unrealized_pnl = 0
   where id = p_id;
  update public.paper_accounts set balance = balance + v_pnl, updated_at = now() where user_id = pos.user_id;
  perform public._paper_refresh_equity(pos.user_id);
  perform public._bot_log(pos.user_id, case when v_pnl < 0 then 'warn' else 'info' end, 'close', pos.symbol,
    format('Closed %s %s @ %s (%s). P&L %s', upper(pos.side), pos.symbol, p_exit, p_reason, v_pnl),
    jsonb_build_object('position_id', pos.id, 'pnl', v_pnl, 'reason', p_reason));
  return v_pnl;
end $$;

-- Closes everything at last known mark and halts. Caller holds locks.
create or replace function public._paper_flatten_and_halt(p_user uuid, p_close_reason text, p_halt_reason text)
returns int language plpgsql security definer set search_path = public, pg_temp as $$
declare r record; n int := 0;
begin
  for r in select id, coalesce(mark_price, entry_price) as px from public.paper_positions where user_id = p_user and status = 'open' order by opened_at loop
    perform public._paper_close(r.id, r.px, p_close_reason);
    n := n + 1;
  end loop;
  update public.bot_settings set status = 'halted', halt_reason = p_halt_reason, halted_at = now(), updated_at = now() where user_id = p_user;
  return n;
end $$;

-- Returns null when within limits, otherwise the breached limit name. Caller holds locks.
create or replace function public._paper_limit_breach(p_user uuid)
returns text language plpgsql stable security definer set search_path = public, pg_temp as $$
declare s public.bot_settings; a public.paper_accounts;
begin
  select * into s from public.bot_settings where user_id = p_user;
  select * into a from public.paper_accounts where user_id = p_user;
  if a.day_start_equity > 0 and (a.day_start_equity - a.equity) / a.day_start_equity * 100 >= s.max_daily_loss_pct then return 'daily_loss_limit'; end if;
  if a.peak_equity > 0 and (a.peak_equity - a.equity) / a.peak_equity * 100 >= s.max_drawdown_pct then return 'max_drawdown'; end if;
  return null;
end $$;

-- ---------------------------------------------------------- service RPCs
create or replace function public.bot_ensure_user(p_user uuid)
returns void language sql security definer set search_path = public, pg_temp as $$
  insert into public.bot_settings(user_id) values (p_user) on conflict (user_id) do nothing;
  insert into public.paper_accounts(user_id) values (p_user) on conflict (user_id) do nothing;
$$;

-- Simple per-user throttle for the control API. true = allowed.
create or replace function public.bot_throttle(p_user uuid, p_ms int)
returns boolean language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  update public.bot_settings set last_control_at = now()
   where user_id = p_user and (last_control_at is null or last_control_at < now() - (p_ms * interval '1 millisecond'));
  get diagnostics n = row_count;
  return n > 0;
end $$;

create or replace function public.bot_save_config(p_user uuid, p_cfg jsonb)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.bot_settings; new_syms text[]; new_tf text; openn int;
begin
  select * into s from public.bot_settings where user_id = p_user for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'Bot not initialised.'); end if;
  new_syms := case when p_cfg ? 'symbols' then array(select jsonb_array_elements_text(p_cfg->'symbols')) else s.symbols end;
  new_tf   := coalesce(p_cfg->>'timeframe', s.timeframe);
  if (new_syms is distinct from s.symbols) or (new_tf <> s.timeframe) then
    if s.status = 'running' then
      return jsonb_build_object('ok', false, 'error', 'Stop the bot before changing markets or timeframe.');
    end if;
    select count(*) into openn from public.paper_positions where user_id = p_user and status = 'open';
    if openn > 0 then
      return jsonb_build_object('ok', false, 'error', 'Close open positions before changing markets or timeframe.');
    end if;
  end if;
  update public.bot_settings set
    symbols            = new_syms,
    timeframe          = new_tf,
    risk_per_trade_pct = coalesce((p_cfg->>'risk_per_trade_pct')::numeric, risk_per_trade_pct),
    max_open_positions = coalesce((p_cfg->>'max_open_positions')::int,     max_open_positions),
    max_daily_loss_pct = coalesce((p_cfg->>'max_daily_loss_pct')::numeric, max_daily_loss_pct),
    max_drawdown_pct   = coalesce((p_cfg->>'max_drawdown_pct')::numeric,   max_drawdown_pct),
    max_trades_per_day = coalesce((p_cfg->>'max_trades_per_day')::int,     max_trades_per_day),
    cooldown_minutes   = coalesce((p_cfg->>'cooldown_minutes')::int,       cooldown_minutes),
    min_score          = coalesce((p_cfg->>'min_score')::int,              min_score),
    rr_ratio           = coalesce((p_cfg->>'rr_ratio')::numeric,           rr_ratio),
    sl_atr_mult        = coalesce((p_cfg->>'sl_atr_mult')::numeric,        sl_atr_mult),
    slippage_bps       = coalesce((p_cfg->>'slippage_bps')::numeric,       slippage_bps),
    close_on_opposite  = coalesce((p_cfg->>'close_on_opposite')::boolean,  close_on_opposite),
    require_htf        = coalesce((p_cfg->>'require_htf')::boolean,        require_htf),
    updated_at = now()
   where user_id = p_user;
  perform public._bot_log(p_user, 'info', 'config', null, 'Configuration saved.', p_cfg);
  return jsonb_build_object('ok', true);
exception when check_violation or invalid_text_representation or numeric_value_out_of_range or data_exception then
  return jsonb_build_object('ok', false, 'error', 'A setting is outside its allowed range.');
end $$;

create or replace function public.bot_start(p_user uuid)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.bot_settings; breach text;
begin
  select * into s from public.bot_settings where user_id = p_user for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'Bot not initialised.'); end if;
  perform 1 from public.paper_accounts where user_id = p_user for update;
  if s.status = 'running' then return jsonb_build_object('ok', true, 'note', 'already running'); end if;
  perform public._paper_roll_day(p_user);
  breach := public._paper_limit_breach(p_user);
  if breach is not null then
    return jsonb_build_object('ok', false, 'error',
      case breach when 'daily_loss_limit' then 'Daily loss limit is reached. Raise the limit, reset the account, or resume after 00:00 UTC.'
                  else 'Max drawdown is reached. Raise the limit or reset the paper account.' end);
  end if;
  update public.bot_settings set status = 'running', halt_reason = null, halted_at = null, started_at = now(), updated_at = now() where user_id = p_user;
  perform public._bot_log(p_user, 'info', 'status', null, format('Bot started (%s, %s, paper trading).', array_to_string(s.symbols, '/'), s.timeframe));
  return jsonb_build_object('ok', true);
end $$;

-- Stop = no new entries. Open positions keep being managed (SL/TP) by the worker.
create or replace function public.bot_stop(p_user uuid)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.bot_settings;
begin
  select * into s from public.bot_settings where user_id = p_user for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'Bot not initialised.'); end if;
  if s.status <> 'stopped' then
    update public.bot_settings set status = 'stopped', halt_reason = null, halted_at = null, updated_at = now() where user_id = p_user;
    perform public._bot_log(p_user, 'info', 'status', null, 'Bot stopped. No new entries; open positions are still managed until they close.');
  end if;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.bot_halt(p_user uuid, p_reason text)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  update public.bot_settings set status = 'halted', halt_reason = p_reason, halted_at = now(), updated_at = now()
   where user_id = p_user and status = 'running';
  if found then perform public._bot_log(p_user, 'error', 'status', null, 'Bot halted: ' || p_reason); end if;
end $$;

create or replace function public.paper_open_position(
  p_user uuid, p_signal_key text, p_symbol text, p_tf text, p_candle_time bigint,
  p_side text, p_score int, p_price numeric, p_sl numeric, p_tp numeric, p_qty numeric)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.bot_settings; a public.paper_accounts; sid uuid; pid uuid; reason text;
        v_risk numeric; v_notional numeric;
begin
  select * into s from public.bot_settings where user_id = p_user for update;
  if not found then return jsonb_build_object('ok', false, 'reason', 'no_settings'); end if;
  select * into a from public.paper_accounts where user_id = p_user for update;

  -- idempotency: a given signal (user + symbol + timeframe + candle) can only ever be processed once
  insert into public.bot_signals(user_id, signal_key, symbol, timeframe, candle_time, side, score, price)
  values (p_user, p_signal_key, p_symbol, p_tf, p_candle_time, p_side, p_score, p_price)
  on conflict (user_id, signal_key) do nothing returning id into sid;
  if sid is null then return jsonb_build_object('ok', false, 'reason', 'duplicate'); end if;

  perform public._paper_roll_day(p_user);
  select * into a from public.paper_accounts where user_id = p_user;

  -- risk and notional are computed here from qty + stop, never taken from the caller
  if p_qty is not null and p_qty > 0 and p_price is not null and p_price > 0 and p_sl is not null and p_side in ('buy','sell') then
    v_risk     := abs(public.paper_pnl(p_symbol, p_side, p_qty, p_price, p_sl));
    v_notional := p_qty * (case when p_symbol = 'USDJPY' then 1 else p_price end);
  end if;

  if s.status <> 'running' then reason := 'bot_not_running';
  elsif v_risk is null or p_tp is null then reason := 'invalid_order';
  elsif (p_side = 'buy'  and not (p_sl < p_price and p_tp > p_price))
     or (p_side = 'sell' and not (p_sl > p_price and p_tp < p_price)) then reason := 'invalid_levels';
  elsif not (p_symbol = any (s.symbols)) or p_tf <> s.timeframe then reason := 'not_configured';
  elsif exists (select 1 from public.paper_positions where user_id = p_user and symbol = p_symbol and status = 'open') then reason := 'position_exists';
  elsif (select count(*) from public.paper_positions where user_id = p_user and status = 'open') >= s.max_open_positions then reason := 'max_open_positions';
  elsif (select count(*) from public.paper_positions where user_id = p_user and opened_at >= date_trunc('day', now() at time zone 'utc') at time zone 'utc') >= s.max_trades_per_day then reason := 'max_trades_per_day';
  elsif s.cooldown_minutes > 0 and exists (select 1 from public.paper_positions where user_id = p_user and symbol = p_symbol and status = 'closed'
                                           and closed_at > now() - (s.cooldown_minutes * interval '1 minute')) then reason := 'cooldown';
  elsif public._paper_limit_breach(p_user) is not null then reason := public._paper_limit_breach(p_user);
  elsif v_risk > a.equity * s.risk_per_trade_pct / 100 * 1.02 then reason := 'risk_too_high';
  elsif v_notional > a.equity * 30 then reason := 'leverage_limit';
  end if;

  if reason is not null then
    update public.bot_signals set outcome = 'skipped', detail = reason where id = sid;
    perform public._bot_log(p_user, 'info', 'skip', p_symbol, format('%s signal on %s skipped: %s', upper(p_side), p_symbol, reason),
      jsonb_build_object('signal_key', p_signal_key, 'reason', reason));
    return jsonb_build_object('ok', false, 'reason', reason);
  end if;

  insert into public.paper_positions(user_id, signal_key, symbol, timeframe, side, qty, entry_price, sl, tp, risk_amount, score, entry_candle_time, mark_price, mark_at)
  values (p_user, p_signal_key, p_symbol, p_tf, p_side, p_qty, p_price, p_sl, p_tp, v_risk, p_score, p_candle_time, p_price, now())
  returning id into pid;
  update public.bot_signals set outcome = 'opened', position_id = pid where id = sid;
  perform public._bot_log(p_user, 'info', 'open', p_symbol,
    format('Opened simulated %s %s @ %s (SL %s, TP %s, score %s)', upper(p_side), p_symbol, p_price, p_sl, p_tp, p_score),
    jsonb_build_object('position_id', pid, 'qty', p_qty, 'risk', v_risk));
  return jsonb_build_object('ok', true, 'position_id', pid);
end $$;

create or replace function public.paper_close_position(p_user uuid, p_position_id uuid, p_exit numeric, p_reason text)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare v numeric; brk text;
begin
  if p_reason not in ('tp','sl','manual','signal_reverse') then return jsonb_build_object('ok', false, 'error', 'Invalid reason.'); end if;
  if p_exit is null or p_exit <= 0 then return jsonb_build_object('ok', false, 'error', 'Invalid price.'); end if;
  perform 1 from public.bot_settings where user_id = p_user for update;
  perform 1 from public.paper_accounts where user_id = p_user for update;
  -- the position must belong to this user (isolation is enforced here, not only by the caller)
  if not exists (select 1 from public.paper_positions where id = p_position_id and user_id = p_user and status = 'open') then
    return jsonb_build_object('ok', false, 'error', 'Position not found or already closed.');
  end if;
  v := public._paper_close(p_position_id, p_exit, p_reason);
  perform public._paper_roll_day(p_user);
  brk := public._paper_limit_breach(p_user);
  if brk is not null then
    perform public._paper_flatten_and_halt(p_user, 'risk_limit', brk);
    perform public._bot_log(p_user, 'error', 'risk', null, 'Risk limit reached (' || brk || '). All positions closed and bot halted.');
  end if;
  return jsonb_build_object('ok', true, 'pnl', v);
end $$;

-- p_marks: {"EURUSD": 1.0841, ...}
create or replace function public.paper_mark_to_market(p_user uuid, p_marks jsonb)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare r record; px numeric; brk text; n int := 0; a public.paper_accounts;
begin
  perform 1 from public.bot_settings where user_id = p_user for update;
  perform 1 from public.paper_accounts where user_id = p_user for update;
  for r in select id, symbol, side, qty, entry_price from public.paper_positions where user_id = p_user and status = 'open' loop
    if p_marks ? r.symbol then
      px := (p_marks->>r.symbol)::numeric;
      if px is not null and px > 0 then
        update public.paper_positions set mark_price = px, mark_at = now(),
               unrealized_pnl = public.paper_pnl(r.symbol, r.side, r.qty, r.entry_price, px) where id = r.id;
      end if;
    end if;
  end loop;
  perform public._paper_refresh_equity(p_user);
  perform public._paper_roll_day(p_user);
  brk := public._paper_limit_breach(p_user);
  if brk is not null then
    n := public._paper_flatten_and_halt(p_user, 'risk_limit', brk);
    perform public._bot_log(p_user, 'error', 'risk', null,
      format('Risk limit reached (%s). %s position(s) closed and bot halted.', brk, n), jsonb_build_object('limit', brk));
  end if;
  select * into a from public.paper_accounts where user_id = p_user;
  return jsonb_build_object('ok', true, 'equity', a.equity, 'halted', brk is not null, 'limit', brk);
end $$;

create or replace function public.paper_emergency_stop(p_user uuid)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  perform 1 from public.bot_settings where user_id = p_user for update;
  perform 1 from public.paper_accounts where user_id = p_user for update;
  n := public._paper_flatten_and_halt(p_user, 'emergency', 'emergency_stop');
  perform public._bot_log(p_user, 'error', 'emergency', null,
    format('EMERGENCY STOP: bot halted, %s simulated position(s) closed at last known price.', n), jsonb_build_object('closed', n));
  return jsonb_build_object('ok', true, 'closed', n);
end $$;

create or replace function public.paper_reset_account(p_user uuid, p_balance numeric)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare s public.bot_settings;
begin
  if p_balance is null or p_balance < 100 or p_balance > 10000000 then
    return jsonb_build_object('ok', false, 'error', 'Starting balance must be between 100 and 10,000,000.');
  end if;
  select * into s from public.bot_settings where user_id = p_user for update;
  if not found then return jsonb_build_object('ok', false, 'error', 'Bot not initialised.'); end if;
  perform 1 from public.paper_accounts where user_id = p_user for update;
  if s.status = 'running' then return jsonb_build_object('ok', false, 'error', 'Stop the bot before resetting the account.'); end if;
  if exists (select 1 from public.paper_positions where user_id = p_user and status = 'open') then
    return jsonb_build_object('ok', false, 'error', 'Close open positions before resetting.');
  end if;
  delete from public.bot_signals   where user_id = p_user;
  delete from public.paper_positions where user_id = p_user;
  update public.paper_accounts set starting_balance = p_balance, balance = p_balance, equity = p_balance, peak_equity = p_balance,
         day_key = (now() at time zone 'utc')::date, day_start_equity = p_balance, updated_at = now() where user_id = p_user;
  update public.bot_settings set status = 'stopped', halt_reason = null, halted_at = null, last_analysis = '{}'::jsonb, updated_at = now() where user_id = p_user;
  perform public._bot_log(p_user, 'info', 'reset', null, format('Paper account reset to %s.', p_balance));
  return jsonb_build_object('ok', true);
end $$;

-- Worker lease: only one worker run at a time (overlapping cron invocations exit immediately).
create or replace function public.bot_acquire_lease(p_name text, p_seconds int, p_holder text)
returns boolean language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  insert into public.bot_worker_lease(name, holder, locked_until) values (p_name, p_holder, now() + (p_seconds * interval '1 second'))
  on conflict (name) do update set holder = excluded.holder, locked_until = excluded.locked_until
    where public.bot_worker_lease.locked_until < now();
  get diagnostics n = row_count;
  return n > 0;
end $$;

create or replace function public.bot_release_lease(p_name text, p_holder text)
returns void language sql security definer set search_path = public, pg_temp as $$
  update public.bot_worker_lease set locked_until = now() where name = p_name and holder = p_holder;
$$;

create or replace function public.bot_prune()
returns void language sql security definer set search_path = public, pg_temp as $$
  delete from public.bot_activity where ts < now() - interval '30 days';
  delete from public.bot_market_state where fetched_at < now() - interval '2 days';
$$;

-- Lock every service function away from browser roles.
do $$ declare f text; begin
  foreach f in array array[
    '_bot_log(uuid,text,text,text,text,jsonb)','paper_pnl(text,text,numeric,numeric,numeric)',
    '_paper_refresh_equity(uuid)','_paper_roll_day(uuid)','_paper_close(uuid,numeric,text)',
    '_paper_flatten_and_halt(uuid,text,text)','_paper_limit_breach(uuid)','bot_ensure_user(uuid)','bot_throttle(uuid,int)',
    'bot_save_config(uuid,jsonb)','bot_start(uuid)','bot_stop(uuid)','bot_halt(uuid,text)',
    'paper_open_position(uuid,text,text,text,bigint,text,int,numeric,numeric,numeric,numeric)',
    'paper_close_position(uuid,uuid,numeric,text)','paper_mark_to_market(uuid,jsonb)','paper_emergency_stop(uuid)',
    'paper_reset_account(uuid,numeric)','bot_acquire_lease(text,int,text)','bot_release_lease(text,text)','bot_prune()'
  ] loop
    execute format('revoke all on function public.%s from public, anon, authenticated', f);
    execute format('grant execute on function public.%s to service_role', f);
  end loop;
end $$;

-- Live updates for the dashboard (RLS still applies to realtime).
do $$ declare t text; begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['bot_settings','paper_accounts','paper_positions','bot_signals','bot_activity'] loop
      begin
        execute format('alter publication supabase_realtime add table public.%I', t);
      exception when duplicate_object then null;
      end;
    end loop;
  end if;
end $$;
