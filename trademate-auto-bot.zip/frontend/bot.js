/* ===== Auto Trading Bot dashboard. PAPER TRADING ONLY: there is no broker code on this page or on the server.
   Reads: the signed-in user's own rows (protected by row-level security) through the existing Supabase client.
   Writes: ONLY through the "bot-control" Edge Function, which re-validates everything on the server.
   No API key, service key or provider key exists in this file (the publishable key is the same one the page already uses). ===== */
const TMBot=(()=>{
const BOT_API=SUPABASE_URL+'/functions/v1/bot-control',$=id=>document.getElementById(id);
const FIELDS=[['Simulation risk limits',[
 ['risk_per_trade_pct','Risk per trade (%)',.1,5,.1,0,'Equity risked on each simulated trade'],
 ['max_open_positions','Max open positions',1,10,1,1,'Across all markets'],
 ['max_daily_loss_pct','Daily loss limit (%)',.5,20,.5,0,'Halts the bot and closes everything until 00:00 UTC'],
 ['max_drawdown_pct','Max drawdown (%)',1,50,1,0,'Fall from peak equity that halts the bot'],
 ['max_trades_per_day','Max trades per day',1,100,1,1,''],
 ['cooldown_minutes','Cooldown per market (min)',0,1440,5,1,'Pause after a trade closes']]],
 ['Strategy',[
 ['min_score','Minimum score',60,100,1,1,'Setups below this are ignored'],
 ['rr_ratio','Reward : risk',.5,10,.1,0,'Target distance = stop distance × this'],
 ['sl_atr_mult','Stop distance (× ATR)',.5,5,.1,0,''],
 ['slippage_bps','Simulated slippage (bps)',0,50,.5,0,'Adverse price move on entry']]]];
const FLAGS=[['close_on_opposite','Close a position on a strong opposite signal'],['require_htf','Require higher-timeframe agreement']];
const RULE={};FIELDS.forEach(g=>g[1].forEach(f=>RULE[f[0]]=f));
const EXIT={tp:'Take profit',sl:'Stop loss',manual:'Closed manually',emergency:'Emergency stop',risk_limit:'Risk limit',signal_reverse:'Opposite signal'};
const HALT={emergency_stop:'Emergency stop was used.',daily_loss_limit:'The daily loss limit was reached. All simulated positions were closed.',max_drawdown:'The max drawdown limit was reached. All simulated positions were closed.',plan_limit:'Your current plan does not include these markets or this timeframe.'};
const STALE_RUN_MS=150000,POLL_MS=15000;

let uid=null,st=null,acct=null,pos=[],closed=[],acts=[],limits=null,plan='free',draft={symbols:[],timeframe:'M15'},dirty=false,
    failed=null,chan=null,rt=false,pollT=null,tickT=null,inflight=null,again=false,pend=0,histN=25,marks={},lastWarn=0,linkErr=false,built=false;

/* ---------- helpers ---------- */
const n=v=>Number(v),fin=v=>Number.isFinite(n(v));
const money=(v,sign)=>{v=Math.round(n(v)*100)/100;if(!Number.isFinite(v))return'–';return(v<0?'-':sign&&v>0?'+':'')+'$'+Math.abs(v).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})};
const cls=v=>n(v)>0?'bull':n(v)<0?'bear':'';
const dp=s=>(S[s]||{d:5}).d,px=(s,v)=>v==null||!fin(v)?'–':n(v).toFixed(dp(s)),nm=s=>(S[s]||{p:s}).p;
const utcs=iso=>iso?new Date(iso).toISOString().slice(5,19).replace('T',' '):'–';
const agoIso=iso=>iso?ago(Date.now()-Date.parse(iso)):'–';
const todayUtc=()=>new Date().toISOString().slice(0,10);
const same=(a,b)=>JSON.stringify([...a].sort())===JSON.stringify([...b].sort());
const say=(id,t,good)=>{const e=$(id);e.textContent=t||'';e.className='err'+(good?' ok':'')};
const toast=m=>TM.toast(m);
const running=()=>!!st&&st.status==='running';
const locked=()=>running()||pos.length>0;

/* ---------- server API (user's JWT; the server validates everything again) ---------- */
async function call(action,extra){
  const sb=TM.client(),{data}=sb?await sb.auth.getSession():{},tok=data&&data.session&&data.session.access_token;
  if(!tok)throw Object.assign(new Error('Please log in.'),{status:401});
  let r,j=null;
  try{r=await fetch(BOT_API,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tok,'apikey':SUPABASE_PUBLISHABLE_KEY},body:JSON.stringify(Object.assign({action},extra||{}))})}
  catch(_){throw Object.assign(new Error('Could not reach the bot service. Check your connection and try again.'),{status:0})}
  try{j=await r.json()}catch(_){}
  if(!r.ok||!j||j.error){
    const m=j&&j.error&&j.error.message;
    throw Object.assign(new Error(m||(r.status===404?'The bot service is not deployed yet.':'The bot service returned an error (HTTP '+r.status+').')),{status:r.status})}
  return j}
function onErr(e,target){
  if(e&&e.status===401){const sb=TM.client();if(sb)sb.auth.signOut({scope:'local'});return}
  const m=(e&&e.message)||'Something went wrong.';if(target)say(target,m);else toast(m)}

/* ---------- data ---------- */
const q=p=>p.then(r=>{if(r.error)throw r.error;return r.data});
async function loadAll(){
  const sb=TM.client(),me=uid;
  const [s,a,o,c,l]=await Promise.all([
    q(sb.from('bot_settings').select('*').eq('user_id',me).maybeSingle()),
    q(sb.from('paper_accounts').select('*').eq('user_id',me).maybeSingle()),
    q(sb.from('paper_positions').select('*').eq('user_id',me).eq('status','open').order('opened_at',{ascending:false})),
    q(sb.from('paper_positions').select('*').eq('user_id',me).eq('status','closed').order('closed_at',{ascending:false}).limit(200)),
    q(sb.from('bot_activity').select('id,ts,level,kind,symbol,message').eq('user_id',me).order('ts',{ascending:false}).order('id',{ascending:false}).limit(100))]);
  if(me!==uid)return;                                   // user changed while loading
  pos.forEach(p=>marks[p.id]=n(p.mark_price));
  if(s)st=s;if(a)acct=a;pos=o||[];closed=c||[];acts=l||[];}
function refresh(){
  if(!uid)return Promise.resolve();
  if(inflight){again=true;return inflight}
  inflight=loadAll().then(()=>{linkErr=false;render()},e=>{linkErr=true;paintLink();
    if(Date.now()-lastWarn>60000){lastWarn=Date.now();toast('Live bot data is temporarily unavailable. Retrying.')}})
   .finally(()=>{inflight=null;if(again){again=false;setTimeout(refresh,300)}});
  return inflight}
let deb=0;const soon=()=>{clearTimeout(deb);deb=setTimeout(refresh,400)};

/* ---------- lifecycle ---------- */
function fatal(msg,hint){
  $('btIn').classList.add('hid');$('btOut').classList.add('hid');const f=$('btFatal');f.classList.remove('hid');
  f.innerHTML='<b class="bear">Auto Bot is unavailable</b><p>'+escH(msg)+'</p>'+(hint?'<p class="note">'+escH(hint)+'</p>':'')+'<button class="b" id="btRetry" type="button">Try again</button>';
  $('btRetry').onclick=()=>{const u=TM.user();stopAll();failed=null;if(u)begin(u)}}
async function begin(u){
  uid=u.id;$('btOut').classList.add('hid');$('btFatal').classList.add('hid');$('btIn').classList.remove('hid');
  if(!built)build();
  $('btPill').textContent='LOADING';
  try{
    const r=await call('init');
    if(uid!==u.id)return;
    if(!r.settings||!r.account)throw Object.assign(new Error('The bot tables are not set up.'),{status:500});
    st=r.settings;acct=r.account;limits=r.limits;plan=r.plan;
    await loadAll();
  }catch(e){
    if(uid!==u.id)return;
    if(e&&e.status===401){onErr(e);return}
    const code=e&&e.code,tbl=code==='PGRST205'||code==='42P01';
    uid=null;failed=u.id;
    fatal(e.status===404?'The bot-control function was not found on your Supabase project.':tbl?'The bot database tables were not found.':(e.message||'The bot service could not be loaded.'),
      e.status===404||tbl||e.status===500?'The site owner needs to finish the Auto Bot setup (database migration and Edge Functions). See SETUP.md.':'');
    return}
  draft={symbols:[...st.symbols],timeframe:st.timeframe};dirty=false;
  render();subscribe();
  clearInterval(pollT);pollT=setInterval(()=>{if(!document.hidden&&uid)refresh()},POLL_MS);
  clearInterval(tickT);tickT=setInterval(tick,1000)}
function stopAll(){
  clearInterval(pollT);clearInterval(tickT);clearTimeout(deb);
  if(chan){try{TM.client().removeChannel(chan)}catch(_){}chan=null}
  uid=null;st=acct=null;pos=[];closed=[];acts=[];marks={};dirty=false;rt=false;linkErr=false;inflight=null;again=false;
  say('btMsg','');say('btCfgErr','');
  $('btIn').classList.add('hid');$('btFatal').classList.add('hid');$('btOut').classList.remove('hid')}
function sync(){
  const u=TM.user();
  if(!u){failed=null;if(uid||!$('btFatal').classList.contains('hid'))stopAll();return}
  if(uid!==u.id&&failed!==u.id){if(uid)stopAll();begin(u)}}
function subscribe(){
  const sb=TM.client();if(!sb||!sb.channel)return;
  try{
    chan=sb.channel('bot-'+uid);
    ['bot_settings','paper_accounts','paper_positions','bot_activity'].forEach(t=>chan.on('postgres_changes',{event:'*',schema:'public',table:t,filter:'user_id=eq.'+uid},soon));
    chan.subscribe(s=>{rt=s==='SUBSCRIBED';paintLink()})
  }catch(_){rt=false}}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&uid)refresh()});

/* ---------- actions ---------- */
function busy(b,on,t){if(on){b.dataset.t=b.textContent;b.innerHTML='<span class="sp"></span>'+(t||'Please wait');b.classList.add('bt-busy');b.disabled=true}else{b.textContent=b.dataset.t||b.textContent;b.classList.remove('bt-busy');b.disabled=false}}
async function act(btn,action,extra,ok,label){
  if(pend)return;pend=1;say('btMsg','');busy(btn,true,label);let r=null;
  try{r=await call(action,extra);if(ok)toast(typeof ok==='function'?ok(r):ok);await refresh()}
  catch(e){onErr(e,'btMsg')}
  finally{pend=0;busy(btn,false);paintHead()}
  return r}
$('btStart').onclick=()=>{if(dirty&&!confirm('You have unsaved settings. Start the bot with the saved settings?'))return;act($('btStart'),'start',null,'Bot started. Analysis now runs on the server.','Starting')};
$('btStop').onclick=()=>act($('btStop'),'stop',null,'Bot stopped. Open positions are still managed until they close.','Stopping');
$('btEmg').onclick=()=>{if(!confirm('EMERGENCY STOP\n\nThis closes every simulated position at the last known price and halts the bot. Continue?'))return;act($('btEmg'),'emergency_stop',null,r=>'Emergency stop: '+r.closed+' simulated position(s) closed.','Stopping')};
$('btReset').onclick=()=>{const v=n($('btBal').value);if(!(v>=100&&v<=1e7))return say('btMsg','Starting balance must be between 100 and 10,000,000.');
  if(!confirm('Reset the paper account to $'+v.toLocaleString()+'? All simulated positions and trade history will be deleted.'))return;
  act($('btReset'),'reset_account',{starting_balance:v,confirm:true},'Paper account reset.','Resetting')};
$('btIn').addEventListener('click',e=>{
  const c=e.target.closest('[data-close]');
  if(c){if(!confirm('Close this simulated position at the last known price?'))return;act(c,'close_position',{position_id:c.dataset.close},'Simulated position closed.','Closing');return}
  if(e.target.id==='btMore'){histN+=25;paintHist()}});

/* ---------- settings form ---------- */
function build(){
  $('btFields').innerHTML=FIELDS.map(g=>`<div class="bt-grp">${g[0]}</div><div class="grid jf">${g[1].map(f=>`<div><label for="btf_${f[0]}">${escH(f[1])}</label><input id="btf_${f[0]}" type="number" inputmode="decimal" min="${f[2]}" max="${f[3]}" step="${f[4]}">${f[6]?`<span class="bt-h">${escH(f[6])}</span>`:''}</div>`).join('')}</div>`).join('')+
    FLAGS.map(f=>`<label class="bt-chk" for="btf_${f[0]}"><input id="btf_${f[0]}" type="checkbox">${escH(f[1])}</label>`).join('');
  $('btForm').addEventListener('input',()=>{dirty=true;$('btDiscard').classList.remove('hid')});
  $('btForm').addEventListener('submit',saveCfg);
  $('btDiscard').onclick=()=>{dirty=false;draft={symbols:[...st.symbols],timeframe:st.timeframe};say('btCfgErr','');paintForm()};
  $('btSyms').addEventListener('click',e=>{const b=e.target.closest('[data-sym]');if(!b||b.disabled)return;
    const s=b.dataset.sym,has=draft.symbols.includes(s),next=Object.keys(S).filter(x=>x===s?!has:draft.symbols.includes(x));
    if(!next.length)return say('btCfgErr','Select at least one market.');
    if(!has&&next.length>limits.maxSymbols)return say('btCfgErr','Your '+plan+' plan allows up to '+limits.maxSymbols+' market'+(limits.maxSymbols>1?'s':'')+' for the bot.');
    say('btCfgErr','');draft.symbols=next;dirty=true;$('btDiscard').classList.remove('hid');paintChips()});
  $('btTfs').addEventListener('click',e=>{const b=e.target.closest('[data-tf]');if(!b||b.disabled)return;say('btCfgErr','');draft.timeframe=b.dataset.tf;dirty=true;$('btDiscard').classList.remove('hid');paintChips()});
  built=true}
function paintChips(){
  const lk=locked();
  $('btSyms').innerHTML=Object.keys(S).map(s=>`<button type="button" class="t" data-sym="${s}" aria-pressed="${draft.symbols.includes(s)}"${lk?' disabled':''}>${escH(S[s].p)}</button>`).join('');
  $('btTfs').innerHTML=TF.map(t=>{const ok=!limits||limits.timeframes.includes(t);return`<button type="button" class="t" data-tf="${t}" aria-pressed="${draft.timeframe===t}"${lk||!ok?' disabled':''}${!ok?` title="Not included in your ${escH(plan)} plan"`:''}>${t}</button>`}).join('');
  $('btLockNote').textContent=lk?(running()?'Stop the bot to change markets or timeframe.':'Close or finish your open positions to change markets or timeframe.'):''}
function paintForm(){
  if(!dirty&&st)draft={symbols:[...st.symbols],timeframe:st.timeframe};
  paintChips();if(dirty||!st)return;
  FIELDS.forEach(g=>g[1].forEach(f=>$('btf_'+f[0]).value=n(st[f[0]])));
  FLAGS.forEach(f=>$('btf_'+f[0]).checked=!!st[f[0]]);
  if(document.activeElement!==$('btBal'))$('btBal').value=n(acct.starting_balance);
  $('btDiscard').classList.add('hid')}
async function saveCfg(ev){
  ev.preventDefault();if(pend)return;say('btCfgErr','');const cfg={};
  for(const k in RULE){const f=RULE[k],raw=$('btf_'+k).value.trim(),v=Number(raw);
    if(raw===''||!Number.isFinite(v)||v<f[2]||v>f[3]||(f[5]&&!Number.isInteger(v)))return say('btCfgErr',f[1]+' must be '+(f[5]?'a whole number ':'a number ')+'between '+f[2]+' and '+f[3]+'.');
    cfg[k]=f[5]?v:Math.round(v*100)/100}
  FLAGS.forEach(f=>cfg[f[0]]=$('btf_'+f[0]).checked);
  if(!same(draft.symbols,st.symbols))cfg.symbols=draft.symbols;
  if(draft.timeframe!==st.timeframe)cfg.timeframe=draft.timeframe;
  const b=$('btSave');pend=1;busy(b,true,'Saving');
  try{await call('save_config',{config:cfg});dirty=false;toast('Settings saved.');await refresh()}
  catch(e){onErr(e,'btCfgErr')}
  finally{pend=0;busy(b,false);paintHead()}}

/* ---------- rendering ---------- */
function render(){paintHead();paintStats();paintEquity();paintAnalysis();paintForm();paintPos();paintHist();paintLog()}
function paintLink(){
  const t=$('btLink');if(!t)return;
  t.className='tag '+(linkErr?'bad':rt?'live':'dl');
  t.textContent=linkErr?'RECONNECTING':rt?'LIVE UPDATES':'UPDATING EVERY '+POLL_MS/1000+'s'}
function paintHead(){
  if(!st)return;
  const r=st.status,p=$('btPill'),since=st.last_run_at?Date.now()-Date.parse(st.last_run_at):null;
  p.className='tag bt-pill '+(r==='running'?'live':r==='halted'?'bad':'');
  p.textContent=r==='running'?'RUNNING':r==='halted'?'HALTED':'STOPPED';
  const lr=$('btRun');
  lr.className='note'+(r==='running'&&(since==null||since>STALE_RUN_MS)?' warn':'');
  lr.textContent=!st.last_run_at?(r==='running'?'Waiting for the first background analysis (up to a minute)…':'No analysis yet.')
    :'Last server analysis '+ago(since)+' ago'+(r==='running'&&since>STALE_RUN_MS?' · the background worker looks delayed':'');
  const h=$('btHalt');h.className='note'+(r==='halted'?' bear':'');
  h.textContent=r==='halted'?'Halted: '+(HALT[st.halt_reason]||st.halt_reason||'stopped by a safety rule')+' Start the bot again when you are ready.':
    r==='stopped'&&pos.length?'The bot is stopped (no new entries). Your '+pos.length+' open simulated position'+(pos.length>1?'s are':' is')+' still managed until a stop or target is hit.':'';
  const lim=limits||{maxSymbols:2,timeframes:[]};
  $('btPlan').textContent='Plan: '+({free:'Free',starter:'Starter',pro:'Pro',premium:'Premium'}[plan]||plan)+' · up to '+lim.maxSymbols+' market'+(lim.maxSymbols>1?'s':'')+' · timeframes '+lim.timeframes.join(', ')+'.';
  const lock=!!pend;
  $('btStart').disabled=lock||r==='running';$('btStop').disabled=lock||r!=='running';$('btEmg').disabled=lock||(r!=='running'&&!pos.length);
  paintLink()}
function tile(k,v,sub){return`<div class="card"><span class="bt-k">${k}</span><div class="bt-v">${v}</div>${sub?`<span class="note">${sub}</span>`:''}</div>`}
function paintStats(){
  if(!acct)return;
  const sb=n(acct.starting_balance),eq=n(acct.equity),bal=n(acct.balance),isToday=acct.day_key===todayUtc(),day=isToday?eq-n(acct.day_start_equity):0,tot=eq-sb,
    open=pos.reduce((a,p)=>a+n(p.unrealized_pnl),0),w=closed.filter(t=>n(t.pnl)>0),l=closed.filter(t=>n(t.pnl)<0),
    gw=w.reduce((a,t)=>a+n(t.pnl),0),gl=-l.reduce((a,t)=>a+n(t.pnl),0),pf=gl>0?(gw/gl).toFixed(2):gw>0?'∞':'–',
    wr=closed.length?Math.round(100*w.length/closed.length)+'%':'–',pc=v=>(v>=0?'+':'')+(v/sb*100).toFixed(2)+'%';
  $('btStats').innerHTML=tile('Equity',money(eq),'Start '+money(sb))+tile('Balance (realised)',money(bal))+
    tile('Today (UTC)',`<span class="${cls(day)}">${money(day,1)}</span>`,pc(day))+tile('Total P&amp;L',`<span class="${cls(tot)}">${money(tot,1)}</span>`,pc(tot))+
    tile('Open P&amp;L',`<span class="${cls(open)}">${money(open,1)}</span>`,pos.length+' open')+tile('Win rate',wr,closed.length+' closed trade'+(closed.length===1?'':'s')+(closed.length>=200?' (last 200)':''))+
    tile('Profit factor',pf,'Gross win ÷ gross loss')+tile('Wins / losses',w.length+' / '+l.length);
  if(!st)return;
  const dl=isToday&&n(acct.day_start_equity)>0?Math.max(0,(n(acct.day_start_equity)-eq)/n(acct.day_start_equity)*100):0,
    dd=n(acct.peak_equity)>0?Math.max(0,(n(acct.peak_equity)-eq)/n(acct.peak_equity)*100):0,
    m=(t,u,lim)=>{const f=lim>0?Math.min(1,u/lim):0;return`<div class="card"><div class="bt-sep"><b>${t}</b><span class="note">limit ${lim}%</span></div><div class="bar"><i style="width:${(f*100).toFixed(1)}%;background:${f>.85?'var(--r)':f>.6?'#f59e0b':'var(--p)'}"></i></div><span class="note">${u.toFixed(2)}% used (${Math.round(f*100)}% of the limit)</span></div>`};
  $('btMeters').innerHTML=m('Daily loss',dl,n(st.max_daily_loss_pct))+m('Drawdown from peak',dd,n(st.max_drawdown_pct))}
function paintEquity(){
  const el=$('btEq');if(!acct)return;
  const asc=closed.slice().reverse();let v=n(acct.balance)-asc.reduce((a,t)=>a+n(t.pnl),0);const pts=[v];asc.forEach(t=>{v+=n(t.pnl);pts.push(v)});
  if(pts.length<2){el.innerHTML='<p class="note" style="margin:14px 0 6px">No closed trades yet. The curve appears after the first simulated trade closes.</p>';return}
  const W=600,H=170,mn=Math.min(...pts),mx=Math.max(...pts),rg=(mx-mn)||Math.max(1,Math.abs(mx)*.01),lo=mn-rg*.12,hi=mx+rg*.12,
    X=i=>i*W/(pts.length-1),Y=y=>H-(y-lo)/(hi-lo)*H,d=pts.map((p,i)=>(i?'L':'M')+X(i).toFixed(1)+' '+Y(p).toFixed(1)).join(' '),
    up=pts[pts.length-1]>=pts[0],c=up?'var(--g)':'var(--r)',by=Y(pts[0]).toFixed(1);
  el.innerHTML=`<svg class="bt-eq" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Realised balance over ${pts.length-1} closed trades, from ${money(pts[0])} to ${money(pts[pts.length-1])}"><defs><linearGradient id="btgr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:${c};stop-opacity:.3"/><stop offset="1" style="stop-color:${c};stop-opacity:0"/></linearGradient></defs><path d="${d} L${W} ${H} L0 ${H} Z" fill="url(#btgr)"/><line x1="0" x2="${W}" y1="${by}" y2="${by}" style="stroke:var(--mu)" stroke-dasharray="4 4" vector-effect="non-scaling-stroke" opacity=".6"/><path d="${d}" fill="none" style="stroke:${c}" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg><p class="note" style="margin:6px 0 0">Low ${money(mn)} · High ${money(mx)} · ${pts.length-1} trade${pts.length>2?'s':''} · dashed line = starting level</p>`}
function dataTag(s){const m={LIVE:['live','LIVE'],DELAYED:['dl','DELAYED'],MARKET_CLOSED:['dl','MARKET CLOSED'],STALE:['bad','STALE'],ERROR:['bad','ERROR'],WAITING:['','WAITING']}[s]||['',String(s||'').replace(/_/g,' ')];return`<span class="tag ${m[0]}">${escH(m[1])}</span>`}
function paintAnalysis(){
  if(!st)return;const la=st.last_analysis||{},rows=st.symbols.map(s=>{const a=la[s];
    if(!a)return`<tr><td>${escH(nm(s))}</td><td colspan="7" class="note">${running()?'Waiting for the next analysis cycle…':'Start the bot to begin analysis.'}</td></tr>`;
    const b=a.status==='BUY'||a.status==='SELL'?`<span class="st ${a.status}">${a.status}</span>`:a.status==='WAIT'?'<span class="st WAIT">NO TRADE</span>':'<span class="st WAIT">NO DATA</span>',
      t=a.trend==null?['–','neu']:tx(a.trend),ok=a.score!=null&&a.score>=n(st.min_score);
    return`<tr><td>${escH(nm(s))}${a.note?`<br><small title="${escH(a.note)}">${escH(String(a.note).slice(0,42))}</small>`:''}</td><td>${b}</td><td>${a.score==null?'–':`<b class="${ok?'bull':''}">${a.score}</b>`}</td><td>${px(s,a.price)}</td><td class="${t[1]}">${t[0]}</td><td>${a.rsi??'–'}</td><td>${a.adx??'–'}</td><td>${dataTag(a.data)}</td></tr>`}).join('');
  $('btAn').innerHTML=`<tr><th>Market</th><th>Signal</th><th>Score <small>(min ${n(st.min_score)})</small></th><th>Price</th><th>Trend</th><th>RSI</th><th>ADX</th><th>Data</th></tr>`+rows;
  $('btAnTs').innerHTML=st.timeframe+' · '+(st.last_run_at?'updated <span data-age="'+escH(st.last_run_at)+'">'+agoIso(st.last_run_at)+'</span> ago':'no analysis yet')}
function paintPos(){
  const el=$('btPos');
  $('btPosTs').textContent=pos.length?'Marked to market by the server every minute':'';
  if(!pos.length){el.innerHTML='<p class="note">No open simulated positions.'+(running()?' The bot opens one when a setup scores at or above your minimum.':'')+'</p>';return}
  const tot=pos.reduce((a,p)=>a+n(p.unrealized_pnl),0);
  el.innerHTML='<table class="bt-tb"><tr><th>Market</th><th>Side</th><th>Size</th><th>Entry</th><th>Mark</th><th>Stop</th><th>Target</th><th>Open P&amp;L</th><th>Risk</th><th>Score</th><th>Opened (UTC)</th><th></th></tr>'+
  pos.map(p=>{const old=marks[p.id],now=n(p.mark_price),fl=old&&now&&old!==now?(((now-old)*(p.side==='buy'?1:-1))>0?' bt-fl-up':' bt-fl-dn'):'';
    return`<tr><td>${escH(nm(p.symbol))}</td><td class="${p.side==='buy'?'bull':'bear'}">${escH(p.side.toUpperCase())}</td><td>${n(p.qty).toLocaleString(undefined,{maximumFractionDigits:2})}</td><td>${px(p.symbol,p.entry_price)}</td><td class="${fl.trim()}">${px(p.symbol,p.mark_price)}</td><td>${px(p.symbol,p.sl)}</td><td>${px(p.symbol,p.tp)}</td><td class="${cls(p.unrealized_pnl)}${fl}">${money(p.unrealized_pnl,1)}</td><td>${money(p.risk_amount)}</td><td>${p.score??'–'}</td><td>${utcs(p.opened_at)}</td><td><button class="t" type="button" data-close="${escH(p.id)}">Close</button></td></tr>`}).join('')+
  `<tr><td colspan="7"><b>Total</b></td><td class="${cls(tot)}"><b>${money(tot,1)}</b></td><td colspan="4"></td></tr></table>`}
function paintHist(){
  const el=$('btHist');
  if(!closed.length){el.innerHTML='<p class="note">No closed simulated trades yet.</p>';return}
  const dur=t=>ago(Date.parse(t.closed_at)-Date.parse(t.opened_at));
  el.innerHTML='<table class="bt-tb"><tr><th>Closed (UTC)</th><th>Market</th><th>Side</th><th>Size</th><th>Entry</th><th>Exit</th><th>P&amp;L</th><th>R</th><th>Result</th><th>Held</th></tr>'+
  closed.slice(0,histN).map(t=>`<tr><td>${utcs(t.closed_at)}</td><td>${escH(nm(t.symbol))}</td><td class="${t.side==='buy'?'bull':'bear'}">${escH(t.side.toUpperCase())}</td><td>${n(t.qty).toLocaleString(undefined,{maximumFractionDigits:2})}</td><td>${px(t.symbol,t.entry_price)}</td><td>${px(t.symbol,t.exit_price)}</td><td class="${cls(t.pnl)}">${money(t.pnl,1)}</td><td class="${cls(t.r_multiple)}">${t.r_multiple==null?'–':(n(t.r_multiple)>0?'+':'')+n(t.r_multiple).toFixed(2)+'R'}</td><td>${escH(EXIT[t.exit_reason]||t.exit_reason||'')}</td><td>${dur(t)}</td></tr>`).join('')+'</table>'+
  (closed.length>histN?`<p style="margin:10px 0 0"><button class="t" type="button" id="btMore">Show more (${closed.length-histN} older)</button></p>`:'')}
function paintLog(){
  $('btLog').innerHTML=acts.length?acts.map(a=>`<div class="${escH(a.level)}"><span class="t0">${utcs(a.ts)}</span><span class="k">${escH(a.kind)}</span><span class="m">${escH(a.message)}</span></div>`).join(''):'<p class="note" style="margin:10px 0 0">No activity yet. Start the bot and its decisions will be logged here.</p>'}
function tick(){
  if(!uid||!st)return;
  document.querySelectorAll('#autobot [data-age]').forEach(e=>e.textContent=agoIso(e.dataset.age));
  if(st.last_run_at)paintHead()}

return{sync,refresh}})();
window.TMBot=TMBot;TMBot.sync();
